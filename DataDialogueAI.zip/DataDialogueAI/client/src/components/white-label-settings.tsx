import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Crown, Palette, Upload, Settings } from "lucide-react";

interface WhiteLabelConfig {
  companyName: string;
  logoUrl: string;
  primaryColor: string;
  secondaryColor: string;
  customDomain: string;
  welcomeMessage: string;
  supportEmail: string;
  customCss: string;
}

export function WhiteLabelSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [config, setConfig] = useState<WhiteLabelConfig>({
    companyName: "DataDialogue AI",
    logoUrl: "",
    primaryColor: "#3b82f6",
    secondaryColor: "#64748b",
    customDomain: "",
    welcomeMessage: "Welcome to your data analytics platform",
    supportEmail: "support@company.com",
    customCss: ""
  });

  const saveMutation = useMutation({
    mutationFn: async (newConfig: WhiteLabelConfig) => {
      const response = await fetch('/api/enterprise/white-label', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newConfig),
      });
      if (!response.ok) throw new Error('Failed to save configuration');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Configuration Saved",
        description: "Your white-label settings have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/enterprise/white-label'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Save Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    saveMutation.mutate(config);
  };

  const handleInputChange = (field: keyof WhiteLabelConfig, value: string) => {
    setConfig(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Crown className="w-6 h-6 text-amber-500" />
        <h2 className="text-2xl font-bold">White-Label Configuration</h2>
        <Badge variant="secondary" className="text-xs">Enterprise Only</Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Branding Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="w-5 h-5" />
              Branding
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="companyName">Company Name</Label>
              <Input
                id="companyName"
                value={config.companyName}
                onChange={(e) => handleInputChange('companyName', e.target.value)}
                placeholder="Your Company Name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="logoUrl">Logo URL</Label>
              <div className="flex gap-2">
                <Input
                  id="logoUrl"
                  value={config.logoUrl}
                  onChange={(e) => handleInputChange('logoUrl', e.target.value)}
                  placeholder="https://your-domain.com/logo.png"
                />
                <Button variant="outline" size="sm">
                  <Upload className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="primaryColor">Primary Color</Label>
                <div className="flex gap-2">
                  <Input
                    id="primaryColor"
                    type="color"
                    value={config.primaryColor}
                    onChange={(e) => handleInputChange('primaryColor', e.target.value)}
                    className="w-16 h-10 p-1"
                  />
                  <Input
                    value={config.primaryColor}
                    onChange={(e) => handleInputChange('primaryColor', e.target.value)}
                    placeholder="#3b82f6"
                    className="flex-1"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="secondaryColor">Secondary Color</Label>
                <div className="flex gap-2">
                  <Input
                    id="secondaryColor"
                    type="color"
                    value={config.secondaryColor}
                    onChange={(e) => handleInputChange('secondaryColor', e.target.value)}
                    className="w-16 h-10 p-1"
                  />
                  <Input
                    value={config.secondaryColor}
                    onChange={(e) => handleInputChange('secondaryColor', e.target.value)}
                    placeholder="#64748b"
                    className="flex-1"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Domain & Content Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="customDomain">Custom Domain</Label>
              <Input
                id="customDomain"
                value={config.customDomain}
                onChange={(e) => handleInputChange('customDomain', e.target.value)}
                placeholder="analytics.yourcompany.com"
              />
              <p className="text-xs text-muted-foreground">
                Contact support to configure DNS settings
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="welcomeMessage">Welcome Message</Label>
              <Textarea
                id="welcomeMessage"
                value={config.welcomeMessage}
                onChange={(e) => handleInputChange('welcomeMessage', e.target.value)}
                placeholder="Welcome message shown to users"
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="supportEmail">Support Email</Label>
              <Input
                id="supportEmail"
                type="email"
                value={config.supportEmail}
                onChange={(e) => handleInputChange('supportEmail', e.target.value)}
                placeholder="support@yourcompany.com"
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Custom CSS */}
      <Card>
        <CardHeader>
          <CardTitle>Custom CSS</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="customCss">Additional CSS Styles</Label>
            <Textarea
              id="customCss"
              value={config.customCss}
              onChange={(e) => handleInputChange('customCss', e.target.value)}
              placeholder="/* Your custom CSS styles */&#10;.custom-class {&#10;  /* styles */&#10;}"
              rows={6}
              className="font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground">
              Add custom CSS to further customize the appearance of your platform
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Preview */}
      <Card className="border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/20">
        <CardHeader>
          <CardTitle className="text-amber-800 dark:text-amber-200">Preview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-4 border rounded-lg bg-white dark:bg-slate-900" style={{ 
            borderColor: config.primaryColor,
            background: `linear-gradient(135deg, ${config.primaryColor}10, ${config.secondaryColor}05)`
          }}>
            <div className="flex items-center gap-3 mb-4">
              {config.logoUrl && (
                <img src={config.logoUrl} alt="Logo" className="w-8 h-8 object-contain" />
              )}
              <h3 className="text-lg font-bold" style={{ color: config.primaryColor }}>
                {config.companyName}
              </h3>
            </div>
            <p className="text-sm text-muted-foreground mb-2">{config.welcomeMessage}</p>
            <div className="text-xs text-muted-foreground">
              Support: {config.supportEmail}
              {config.customDomain && ` • Domain: ${config.customDomain}`}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button 
          onClick={handleSave}
          disabled={saveMutation.isPending}
          className="min-w-32"
        >
          {saveMutation.isPending ? "Saving..." : "Save Configuration"}
        </Button>
      </div>
    </div>
  );
}