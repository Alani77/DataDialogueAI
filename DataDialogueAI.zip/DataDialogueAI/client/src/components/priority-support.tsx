import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Crown, Phone, Mail, MessageCircle, Clock, User, AlertCircle } from "lucide-react";

export function PrioritySupport() {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Crown className="w-6 h-6 text-amber-500" />
        <h2 className="text-2xl font-bold">Priority Support</h2>
        <Badge variant="secondary" className="text-xs">Enterprise Only</Badge>
      </div>

      {/* Support Level Info */}
      <Card className="border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-amber-800 dark:text-amber-200">
            <Crown className="w-5 h-5" />
            Enterprise Support Level Active
          </CardTitle>
        </CardHeader>
        <CardContent className="text-amber-700 dark:text-amber-300">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>24/7 Priority Response</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>Dedicated Account Manager</span>
            </div>
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              <span>Critical Issue SLA: 2 hours</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Emergency Support */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-600 dark:text-red-400">
              <AlertCircle className="w-5 h-5" />
              Emergency Support
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              For critical production issues requiring immediate attention
            </p>
            <div className="space-y-3">
              <Button className="w-full bg-red-600 hover:bg-red-700">
                <Phone className="w-4 h-4 mr-2" />
                Call Emergency Line
              </Button>
              <div className="text-center text-sm text-muted-foreground">
                +1 (555) 123-4567
                <br />
                Available 24/7
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Account Manager */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Account Manager
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="w-6 h-6 text-primary" />
              </div>
              <div>
                <div className="font-medium">Sarah Johnson</div>
                <div className="text-sm text-muted-foreground">Senior Account Manager</div>
              </div>
            </div>
            <div className="space-y-2">
              <Button variant="outline" className="w-full">
                <Mail className="w-4 h-4 mr-2" />
                sarah.johnson@datadialogue.ai
              </Button>
              <Button variant="outline" className="w-full">
                <Phone className="w-4 h-4 mr-2" />
                +1 (555) 123-4568
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Business hours: Mon-Fri 8AM-6PM PST
            </p>
          </CardContent>
        </Card>

        {/* Technical Support */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              Technical Support
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              For technical questions and implementation support
            </p>
            <div className="space-y-2">
              <Button className="w-full">
                <MessageCircle className="w-4 h-4 mr-2" />
                Start Priority Chat
              </Button>
              <Button variant="outline" className="w-full">
                <Mail className="w-4 h-4 mr-2" />
                Email Technical Team
              </Button>
            </div>
            <div className="text-xs text-muted-foreground">
              Average response time: 30 minutes
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Support Features */}
      <Card>
        <CardHeader>
          <CardTitle>Enterprise Support Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-medium">Priority Response Times</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Critical Issues:</span>
                  <span className="font-medium text-red-600">2 hours</span>
                </div>
                <div className="flex justify-between">
                  <span>High Priority:</span>
                  <span className="font-medium text-orange-600">4 hours</span>
                </div>
                <div className="flex justify-between">
                  <span>Medium Priority:</span>
                  <span className="font-medium text-yellow-600">12 hours</span>
                </div>
                <div className="flex justify-between">
                  <span>Low Priority:</span>
                  <span className="font-medium text-green-600">24 hours</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium">Additional Benefits</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Custom integration support</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Training sessions for your team</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Quarterly business reviews</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Beta feature access</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Priority feature requests</span>
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Support Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Support Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start gap-4 p-3 border rounded-lg">
              <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                <AlertCircle className="w-4 h-4 text-green-600 dark:text-green-400" />
              </div>
              <div className="flex-1">
                <div className="font-medium">API Integration Issue - Resolved</div>
                <div className="text-sm text-muted-foreground">
                  Ticket #ENT-2024-001 • Resolved in 1.5 hours
                </div>
                <div className="text-xs text-muted-foreground mt-1">
                  Handled by: Technical Support Team
                </div>
              </div>
              <Badge variant="outline" className="text-green-600 border-green-200">
                Resolved
              </Badge>
            </div>

            <div className="flex items-start gap-4 p-3 border rounded-lg">
              <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                <MessageCircle className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              </div>
              <div className="flex-1">
                <div className="font-medium">White-label Configuration</div>
                <div className="text-sm text-muted-foreground">
                  Ticket #ENT-2024-002 • In Progress
                </div>
                <div className="text-xs text-muted-foreground mt-1">
                  Handled by: Sarah Johnson (Account Manager)
                </div>
              </div>
              <Badge variant="outline" className="text-blue-600 border-blue-200">
                In Progress
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}