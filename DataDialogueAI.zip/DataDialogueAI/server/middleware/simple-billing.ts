import { Request, Response, NextFunction } from 'express';
import { simpleBillingService } from '../services/simple-billing';
import { TOKEN_COSTS } from '@shared/schema';

interface AuthenticatedRequest extends Request {
  user?: {
    claims: {
      sub: string;
    };
  };
  tokenAction?: keyof typeof TOKEN_COSTS;
}

export function checkTokenLimit(action: keyof typeof TOKEN_COSTS) {
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const userId = req.user?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ error: 'Authentication required' });
      }
      
      const result = await simpleBillingService.checkTokenLimit(userId, action);
      
      if (!result.allowed) {
        if (result.upgradeRequired) {
          return res.status(402).json({
            error: result.reason,
            upgradeRequired: true,
            plans: ['flat', 'payg', 'enterprise']
          });
        }
        
        return res.status(429).json({
          error: result.reason,
          retryAfter: 3600
        });
      }
      
      req.tokenAction = action;
      next();
    } catch (error) {
      console.error('Token limit check failed:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  };
}

export async function consumeTokens(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    if (!req.tokenAction) {
      return next();
    }
    
    const userId = req.user?.claims?.sub;
    if (!userId) {
      return next(); // Skip if no authenticated user
    }
    
    const result = await simpleBillingService.consumeTokens(userId, req.tokenAction);
    
    if (!result.success) {
      console.error('Failed to consume tokens:', result.error);
    }
    
    if (result.cost && result.cost > 0) {
      res.setHeader('X-Token-Cost', result.cost.toString());
    }
    
    next();
  } catch (error) {
    console.error('Token consumption failed:', error);
    next();
  }
}

export async function resetTokens(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const userId = req.user?.claims?.sub;
    if (userId) {
      await simpleBillingService.resetDailyTokensIfNeededPublic(userId);
      await simpleBillingService.resetMonthlyTokensIfNeededPublic(userId);
    }
    next();
  } catch (error) {
    console.error('Token reset failed:', error);
    next();
  }
}

declare global {
  namespace Express {
    interface Request {
      tokenAction?: keyof typeof TOKEN_COSTS;
      userId?: string;
    }
  }
}