import { Request, Response, NextFunction } from 'express';
import { billingService } from '../services/billing';
import { TOKEN_COSTS } from '@shared/schema';

interface AuthenticatedRequest extends Request {
  userId?: string;
}

export function checkTokenLimit(action: keyof typeof TOKEN_COSTS) {
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      // For now, we'll use a default user ID since we don't have authentication yet
      // In production, this would come from the authenticated user session
      const userId = req.userId || 'default-user';
      
      const result = await billingService.checkTokenLimit(userId, action);
      
      if (!result.allowed) {
        if (result.upgradeRequired) {
          return res.status(402).json({
            error: result.reason,
            upgradeRequired: true,
            plans: ['flat', 'payg', 'enterprise']
          });
        }
        
        return res.status(429).json({
          error: result.reason,
          retryAfter: 3600 // Retry after 1 hour for daily limits
        });
      }
      
      // Store the action in request for consumption after successful operation
      req.tokenAction = action;
      next();
    } catch (error) {
      console.error('Token limit check failed:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  };
}

export async function consumeTokens(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    if (!req.tokenAction) {
      return next();
    }
    
    const userId = req.userId || 'default-user';
    const result = await billingService.consumeTokens(userId, req.tokenAction);
    
    if (!result.success) {
      console.error('Failed to consume tokens:', result.error);
    }
    
    // Add billing info to response headers
    if (result.cost && result.cost > 0) {
      res.setHeader('X-Token-Cost', result.cost.toString());
    }
    
    next();
  } catch (error) {
    console.error('Token consumption failed:', error);
    next(); // Don't block the request if billing fails
  }
}

// Middleware to reset daily tokens if needed
export async function resetDailyTokens(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const userId = req.userId || 'default-user';
    await billingService.resetDailyTokensIfNeeded(userId);
    await billingService.resetMonthlyTokensIfNeeded(userId);
    next();
  } catch (error) {
    console.error('Token reset failed:', error);
    next(); // Don't block the request
  }
}

declare global {
  namespace Express {
    interface Request {
      tokenAction?: keyof typeof TOKEN_COSTS;
      userId?: string;
    }
  }
}