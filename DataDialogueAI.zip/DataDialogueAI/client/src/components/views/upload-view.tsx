import FileUpload from "@/components/file-upload";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Upload, FileText, Database, CheckCircle } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function UploadView() {
  const supportedFormats = [
    { name: "CSV", description: "Comma-separated values", extension: ".csv" },
    { name: "TSV", description: "Tab-separated values", extension: ".tsv" },
    { name: "Excel", description: "Microsoft Excel files", extension: ".xlsx, .xls" },
    { name: "JSON", description: "JavaScript Object Notation", extension: ".json" },
    { name: "XML", description: "Extensible Markup Language", extension: ".xml" }
  ];

  const features = [
    "Automatic data type detection",
    "Smart column mapping",
    "Data validation and cleaning",
    "Preview before processing",
    "Secure file handling",
    "Progress tracking"
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Upload Data</h1>
        <p className="text-slate-600 dark:text-slate-400">Upload your datasets to start analyzing with AI</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upload Component */}
        <div className="lg:col-span-2">
          <FileUpload onDatasetUploaded={() => {}} />
        </div>

        {/* Sidebar with Info */}
        <div className="space-y-4">
          {/* Supported Formats */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Supported Formats
              </CardTitle>
              <CardDescription>
                We support various data file formats
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {supportedFormats.map((format) => (
                <div key={format.name} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium text-slate-900 dark:text-slate-100">{format.name}</p>
                    <p className="text-sm text-slate-600 dark:text-slate-400">{format.description}</p>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {format.extension}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Features */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Database className="w-5 h-5" />
                Processing Features
              </CardTitle>
              <CardDescription>
                Advanced data processing capabilities
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span className="text-sm text-slate-700 dark:text-slate-300">{feature}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* File Limits */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Upload className="w-5 h-5" />
                Upload Limits
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600 dark:text-slate-400">Max file size:</span>
                <Badge variant="secondary">50 MB</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600 dark:text-slate-400">Max rows:</span>
                <Badge variant="secondary">1M rows</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600 dark:text-slate-400">Processing time:</span>
                <Badge variant="secondary">~30 seconds</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Tips */}
      <Card className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2 text-blue-700 dark:text-blue-300">
            💡 Upload Tips
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-blue-700 dark:text-blue-300">
          <p className="text-sm">• Ensure your data has clear column headers in the first row</p>
          <p className="text-sm">• Remove any empty rows or columns before uploading</p>
          <p className="text-sm">• For best results, use consistent date formats (YYYY-MM-DD)</p>
          <p className="text-sm">• Large files may take longer to process - please be patient</p>
        </CardContent>
      </Card>
    </div>
  );
}