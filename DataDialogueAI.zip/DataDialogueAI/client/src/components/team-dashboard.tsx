import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Activity, TrendingUp, Database, Crown } from "lucide-react";

interface TeamStats {
  totalMembers: number;
  activeMembers: number;
  totalTokensUsed: number;
  totalDatasets: number;
  topUsers: Array<{
    id: string;
    name: string;
    tokensUsed: number;
    datasetsCreated: number;
  }>;
  monthlyUsage: Array<{
    month: string;
    tokens: number;
    queries: number;
  }>;
}

export function TeamDashboard() {
  const { data: teamStats, isLoading } = useQuery<TeamStats>({
    queryKey: ['/api/enterprise/team-stats'],
    refetchInterval: 60000, // Refresh every minute
  });

  if (isLoading || !teamStats) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-2 mb-6">
          <Crown className="w-6 h-6 text-amber-500" />
          <h2 className="text-2xl font-bold">Enterprise Team Dashboard</h2>
          <Badge variant="secondary" className="text-xs">Enterprise Only</Badge>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-3">
                <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded animate-pulse" />
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-slate-200 dark:bg-slate-700 rounded animate-pulse" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Crown className="w-6 h-6 text-amber-500" />
        <h2 className="text-2xl font-bold">Enterprise Team Dashboard</h2>
        <Badge variant="secondary" className="text-xs">Enterprise Only</Badge>
      </div>

      {/* Team Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Members</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{teamStats.totalMembers}</div>
            <p className="text-xs text-muted-foreground">
              {teamStats.activeMembers} active this month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tokens Used</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{teamStats.totalTokensUsed.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              This month across all members
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Datasets</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{teamStats.totalDatasets}</div>
            <p className="text-xs text-muted-foreground">
              Total datasets uploaded
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Growth</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">+12%</div>
            <p className="text-xs text-muted-foreground">
              Usage vs last month
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Users */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Top Team Members</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {teamStats.topUsers.map((user, index) => (
                <div key={user.id} className="flex items-center gap-4">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">{user.name}</div>
                    <div className="text-sm text-muted-foreground">
                      {user.tokensUsed} tokens • {user.datasetsCreated} datasets
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Monthly Usage Trend */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Monthly Usage Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {teamStats.monthlyUsage.map((month, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="font-medium">{month.month}</div>
                  <div className="text-right">
                    <div className="font-bold">{month.tokens} tokens</div>
                    <div className="text-sm text-muted-foreground">{month.queries} queries</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Enterprise Features Info */}
      <Card className="border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-amber-800 dark:text-amber-200">
            <Crown className="w-5 h-5" />
            Enterprise Features Active
          </CardTitle>
        </CardHeader>
        <CardContent className="text-amber-700 dark:text-amber-300">
          <ul className="space-y-2 text-sm">
            <li>• Team dashboard with real-time analytics</li>
            <li>• Priority support with dedicated account manager</li>
            <li>• White-label options for custom branding</li>
            <li>• Custom integrations and API access</li>
            <li>• Advanced user management and permissions</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}