import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { CloudUpload, FileText, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileUploadProps {
  onDatasetUploaded: (datasetId: string) => void;
}

interface UploadResponse {
  datasetId: string;
  filename: string;
  fileType: string;
  rowCount: number;
  columns: any[];
  preview: any[];
}

export default function FileUpload({ onDatasetUploaded }: FileUploadProps) {
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File): Promise<UploadResponse> => {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Upload failed');
      }

      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "File uploaded successfully",
        description: `Processed ${data.rowCount} rows from ${data.filename}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/datasets'] });
      onDatasetUploaded(data.datasetId);
      setSelectedFile(null);
      setUploadProgress(0);
    },
    onError: (error: Error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
      setUploadProgress(0);
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      setSelectedFile(file);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'text/tab-separated-values': ['.tsv'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls'],
      'application/json': ['.json'],
      'application/xml': ['.xml'],
      'text/xml': ['.xml'],
    },
    multiple: false,
  });

  const handleUpload = () => {
    if (selectedFile) {
      setUploadProgress(10);
      uploadMutation.mutate(selectedFile);
    }
  };

  const removeFile = () => {
    setSelectedFile(null);
    setUploadProgress(0);
  };

  const supportedFormats = ["CSV", "TSV", "XLSX", "XLS", "JSON", "XML"];

  return (
    <div className="space-y-8">
      {/* File Upload Area */}
      <Card>
        <CardContent className="p-8">
          <div
            {...getRootProps()}
            className={cn(
              "border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-300",
              isDragActive 
                ? "border-primary bg-primary/5" 
                : "border-slate-300 dark:border-slate-600 hover:border-primary hover:bg-primary/5"
            )}
          >
            <input {...getInputProps()} />
            <div className="flex flex-col items-center space-y-4">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                <CloudUpload className="w-8 h-8 text-primary" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                  {isDragActive ? "Drop your data file here" : "Drop your data files here"}
                </h3>
                <p className="text-slate-600 dark:text-slate-400">
                  Supports {supportedFormats.join(", ")}
                </p>
              </div>
              <Button type="button" className="bg-primary text-white hover:bg-primary/90">
                Choose Files
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Selected File */}
      {selectedFile && (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <FileText className="w-5 h-5 text-slate-600 dark:text-slate-400" />
                <div>
                  <p className="font-medium text-slate-900 dark:text-slate-100">{selectedFile.name}</p>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={removeFile}>
                <X className="w-4 h-4" />
              </Button>
            </div>

            {uploadProgress > 0 && (
              <div className="mb-4">
                <Progress value={uploadProgress} className="w-full" />
              </div>
            )}

            <Button 
              onClick={handleUpload}
              disabled={uploadMutation.isPending}
              className="w-full bg-primary text-white hover:bg-primary/90"
            >
              {uploadMutation.isPending ? "Processing..." : "Upload & Analyze"}
            </Button>
          </CardContent>
        </Card>
      )}


    </div>
  );
}
