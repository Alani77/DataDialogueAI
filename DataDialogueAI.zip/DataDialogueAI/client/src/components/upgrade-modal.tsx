import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Zap, TrendingUp, Crown, CreditCard } from "lucide-react";
import { PRICING_PLANS, type PlanType } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan?: string;
  reason?: string;
}

export function UpgradeModal({ isOpen, onClose, currentPlan = 'free', reason }: UpgradeModalProps) {
  const [selectedPlan, setSelectedPlan] = useState<PlanType>('flat');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const handleUpgrade = (planType: PlanType) => {
    if (planType === 'payg') {
      // Redirect to token purchase page for pay-as-you-go
      window.location.href = '/token-purchase';
    } else if (planType === 'flat' || planType === 'enterprise') {
      // Redirect to Stripe checkout for subscription plans
      window.location.href = `/checkout/${planType}`;
    } else {
      // Free plan - use existing API
      upgradeMutation.mutate(planType);
    }
  };

  const upgradeMutation = useMutation({
    mutationFn: async (planType: PlanType) => {
      const response = await fetch('/api/billing/upgrade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planType }),
      });

      if (!response.ok) {
        throw new Error('Failed to upgrade plan');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Plan updated successfully!",
        description: "Your plan has been updated.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/billing/usage'] });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const plans = [
    {
      key: 'flat' as PlanType,
      ...PRICING_PLANS.flat,
      icon: <TrendingUp className="w-5 h-5" />,
      popular: true,
      features: [
        '150 tokens per month',
        'Overage at $0.012/token',
        'All data formats supported',
        'AI-powered insights',
        'Email support'
      ]
    },
    {
      key: 'payg' as PlanType,
      ...PRICING_PLANS.payg,
      icon: <CreditCard className="w-5 h-5" />,
      popular: false,
      features: [
        'Pay only for what you use',
        '$0.02 per token',
        'No monthly commitment',
        'All data formats supported',
        'AI-powered insights'
      ]
    },
    {
      key: 'enterprise' as PlanType,
      ...PRICING_PLANS.enterprise,
      icon: <Crown className="w-5 h-5" />,
      popular: false,
      features: [
        '1,500 tokens per month',
        'Overage at $0.005/token',
        'Team dashboards',
        'Priority support',
        'White-label options',
        'Custom integrations'
      ]
    }
  ];



  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary" />
            Upgrade Your Plan
          </DialogTitle>
          <DialogDescription>
            {reason || "Choose a plan that fits your data analysis needs"}
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
          {plans.map((plan) => (
            <Card 
              key={plan.key}
              className={`cursor-pointer transition-all ${
                selectedPlan === plan.key 
                  ? 'ring-2 ring-primary shadow-lg' 
                  : 'hover:shadow-md'
              } ${plan.popular ? 'border-primary' : ''}`}
              onClick={() => setSelectedPlan(plan.key)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {plan.icon}
                    <CardTitle className="text-lg">{plan.name}</CardTitle>
                  </div>
                  {plan.popular && (
                    <Badge variant="default" className="text-xs">
                      Popular
                    </Badge>
                  )}
                </div>
                <div className="space-y-1">
                  <div className="text-3xl font-bold">
                    ${plan.price}
                    <span className="text-sm font-normal text-slate-600 dark:text-slate-400">
                      {plan.price > 0 ? '/month' : ''}
                    </span>
                  </div>
                  {plan.key === 'payg' && (
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      + $0.02 per token
                    </p>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-2">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                {selectedPlan === plan.key && (
                  <div className="p-2 bg-primary/10 rounded text-xs text-primary font-medium">
                    ✓ Selected
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex items-center justify-between pt-4 border-t">
          <div className="text-sm text-slate-600 dark:text-slate-400">
            Current plan: <span className="font-medium capitalize">{currentPlan}</span>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              onClick={() => handleUpgrade(selectedPlan)}
              disabled={upgradeMutation.isPending}
              className="min-w-24"
            >
              {upgradeMutation.isPending ? "Upgrading..." : "Upgrade"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}