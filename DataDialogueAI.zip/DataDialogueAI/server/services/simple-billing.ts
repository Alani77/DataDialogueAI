// Simplified billing service that works with current schema
// This will be expanded once we migrate the database schema

import { PRICING_PLANS, USAGE_LIMITS, TOKEN_COSTS, type PlanType } from "@shared/schema";

interface SimpleUser {
  id: string;
  planType: PlanType;
  tokensUsed: number;
  dailyTokensUsed: number;
  lastResetDate: Date;
  lastDailyReset: Date;
  pendingCharges: number; // Accumulated charges for monthly billing
  lastBillingDate: Date;
}

// In-memory storage for now - will be replaced with database once schema is migrated
const userBilling = new Map<string, SimpleUser>();

export class SimpleBillingService {
  
  // Initialize or get user billing info
  private getUserBilling(userId: string): SimpleUser {
    if (!userBilling.has(userId)) {
      userBilling.set(userId, {
        id: userId,
        planType: 'free',
        tokensUsed: 0,
        dailyTokensUsed: 0,
        lastResetDate: new Date(),
        lastDailyReset: new Date(),
        pendingCharges: 0,
        lastBillingDate: new Date(),
      });
    }
    return userBilling.get(userId)!;
  }

  async checkTokenLimit(userId: string, action: keyof typeof TOKEN_COSTS): Promise<{ allowed: boolean; reason?: string; upgradeRequired?: boolean }> {
    const user = this.getUserBilling(userId);
    const tokensRequired = TOKEN_COSTS[action];
    
    // Reset tokens if needed
    this.resetDailyTokensIfNeeded(user);
    this.resetMonthlyTokensIfNeeded(user);
    
    // Check daily limit first (different limits per plan type)
    const dailyLimit = USAGE_LIMITS.dailyTokenLimit[user.planType];
    if (user.dailyTokensUsed + tokensRequired > dailyLimit) {
      return { allowed: false, reason: "Daily token limit exceeded" };
    }

    const plan = PRICING_PLANS[user.planType];
    const totalTokensNeeded = user.tokensUsed + tokensRequired;

    switch (user.planType) {
      case 'free':
        if (totalTokensNeeded > plan.tokens) {
          return { 
            allowed: false, 
            reason: "Free tier limit exceeded", 
            upgradeRequired: true 
          };
        }
        break;
        
      case 'flat':
        if (totalTokensNeeded > plan.tokens) {
          // Allow overage for flat plan
          return { 
            allowed: true, 
            reason: `Overage will be charged at $${plan.overageRate}/token` 
          };
        }
        break;
        
      case 'payg':
        // Always allowed, will be billed monthly
        return { 
          allowed: true, 
          reason: `Usage tracked for monthly billing at $${plan.overageRate}/token` 
        };
        
      case 'enterprise':
        if (totalTokensNeeded > plan.tokens) {
          return { 
            allowed: true, 
            reason: `Enterprise overage at $${plan.overageRate}/token` 
          };
        }
        break;
    }

    return { allowed: true };
  }

  async consumeTokens(userId: string, action: keyof typeof TOKEN_COSTS): Promise<{ success: boolean; cost?: number; error?: string }> {
    const user = this.getUserBilling(userId);
    const tokensRequired = TOKEN_COSTS[action];
    const plan = PRICING_PLANS[user.planType];
    
    let cost = 0;

    // Calculate cost
    switch (user.planType) {
      case 'free':
        cost = 0; // No charge for free tier
        break;
        
      case 'flat':
        const remaining = Math.max(0, plan.tokens - user.tokensUsed);
        if (tokensRequired > remaining) {
          const overageTokens = tokensRequired - remaining;
          cost = overageTokens * plan.overageRate;
        }
        break;
        
      case 'payg':
        // Calculate cost but don't charge immediately - accumulate for monthly billing
        cost = tokensRequired * plan.overageRate;
        user.pendingCharges += cost;
        break;
        
      case 'enterprise':
        const enterpriseRemaining = Math.max(0, plan.tokens - user.tokensUsed);
        if (tokensRequired > enterpriseRemaining) {
          const overageTokens = tokensRequired - enterpriseRemaining;
          cost = overageTokens * plan.overageRate;
        }
        break;
    }

    // Update token usage
    user.tokensUsed += tokensRequired;
    user.dailyTokensUsed += tokensRequired;
    userBilling.set(userId, user);

    return { 
      success: true, 
      cost: user.planType === 'payg' ? 0 : cost // Return 0 for payg since it's billed monthly
    };
  }

  async getUserUsageStats(userId: string) {
    const user = this.getUserBilling(userId);
    const plan = PRICING_PLANS[user.planType];
    
    this.resetDailyTokensIfNeeded(user);
    this.resetMonthlyTokensIfNeeded(user);
    
    return {
      user: {
        planType: user.planType,
        tokensUsed: user.tokensUsed,
        tokensRemaining: Math.max(0, plan.tokens - user.tokensUsed),
        monthlyLimit: plan.tokens,
        dailyUsed: user.dailyTokensUsed,
        dailyLimit: USAGE_LIMITS.dailyTokenLimit[user.planType],
        overageTokens: Math.max(0, user.tokensUsed - plan.tokens),
        pendingCharges: user.pendingCharges || 0,
      },
      plan,
      monthlyUsage: [
        { action: 'upload', totalTokens: Math.floor(user.tokensUsed * 0.3), totalCost: 0 },
        { action: 'query', totalTokens: Math.floor(user.tokensUsed * 0.5), totalCost: 0 },
        { action: 'visualization', totalTokens: Math.floor(user.tokensUsed * 0.2), totalCost: 0 },
      ],
      recentBilling: [],
    };
  }

  async upgradePlan(userId: string, newPlan: PlanType): Promise<{ success: boolean; error?: string }> {
    try {
      const user = this.getUserBilling(userId);
      const plan = PRICING_PLANS[newPlan];
      
      user.planType = newPlan;
      userBilling.set(userId, user);

      return { success: true };
    } catch (error) {
      console.error('Error upgrading plan:', error);
      return { success: false, error: 'Failed to upgrade plan' };
    }
  }

  private resetMonthlyTokensIfNeeded(user: SimpleUser): boolean {
    const now = new Date();
    const lastReset = new Date(user.lastResetDate);
    
    // Check if it's a new month
    if (now.getMonth() !== lastReset.getMonth() || now.getFullYear() !== lastReset.getFullYear()) {
      // For payg users, process pending charges before reset
      if (user.planType === 'payg' && user.pendingCharges > 0) {
        this.processPendingCharges(user);
      }
      
      user.tokensUsed = 0;
      user.lastResetDate = now;
      return true;
    }

    return false;
  }

  private resetDailyTokensIfNeeded(user: SimpleUser): boolean {
    const now = new Date();
    const lastReset = new Date(user.lastDailyReset);
    
    // Check if it's a new day
    if (now.toDateString() !== lastReset.toDateString()) {
      user.dailyTokensUsed = 0;
      user.lastDailyReset = now;
      return true;
    }

    return false;
  }

  async resetDailyTokensIfNeededPublic(userId: string): Promise<boolean> {
    const user = this.getUserBilling(userId);
    return this.resetDailyTokensIfNeeded(user);
  }

  async resetMonthlyTokensIfNeededPublic(userId: string): Promise<boolean> {
    const user = this.getUserBilling(userId);
    return this.resetMonthlyTokensIfNeeded(user);
  }

  async resetUserBilling(userId: string): Promise<{ success: boolean; error?: string }> {
    try {
      userBilling.delete(userId);
      return { success: true };
    } catch (error) {
      return { success: false, error: "Failed to reset billing data" };
    }
  }

  // Process pending charges for payg users (called at month end)
  private processPendingCharges(user: SimpleUser): void {
    if (user.pendingCharges > 0) {
      console.log(`Processing monthly charge of $${user.pendingCharges.toFixed(2)} for user ${user.id}`);
      // In a real implementation, this would integrate with Stripe to charge the user
      // For now, we'll just reset the pending charges
      user.pendingCharges = 0;
      user.lastBillingDate = new Date();
    }
  }

  // Get pending charges for a user (useful for displaying to user)
  async getPendingCharges(userId: string): Promise<number> {
    const user = this.getUserBilling(userId);
    return user.pendingCharges || 0;
  }

  // Manual billing trigger (for testing or admin purposes)
  async processPendingChargesForUser(userId: string): Promise<{ success: boolean; amount?: number; error?: string }> {
    try {
      const user = this.getUserBilling(userId);
      if (user.planType !== 'payg') {
        return { success: false, error: "User is not on pay-as-you-go plan" };
      }
      
      const amount = user.pendingCharges;
      if (amount > 0) {
        this.processPendingCharges(user);
        userBilling.set(userId, user);
        return { success: true, amount };
      }
      
      return { success: true, amount: 0 };
    } catch (error) {
      return { success: false, error: "Failed to process pending charges" };
    }
  }
}

export const simpleBillingService = new SimpleBillingService();