import type { Express } from "express";
import { createServer, type Server } from "http";

import multer from "multer";
import Stripe from "stripe";
import { storage } from "./storage";
import { analyzeDataWithAI, generateVisualization } from "./services/openai";
import { processCSV, processTSV, processExcel, processJSON, processXML } from "./services/file-processor";
import { simpleBillingService } from "./services/simple-billing";
import { checkTokenLimit, consumeTokens, resetTokens } from "./middleware/simple-billing";
import { PRICING_PLANS } from "../shared/schema";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { z } from "zod";

// Initialize Stripe
if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-07-30.basil",
});

const upload = multer({ storage: multer.memoryStorage() });

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Apply token reset middleware to all routes
  app.use(resetTokens as any);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // File upload endpoint with token limiting
  app.post("/api/upload", isAuthenticated, upload.single('file'), checkTokenLimit('upload') as any, async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { originalname, buffer, mimetype } = req.file;
      const userId = req.user.claims.sub;

      let processedData;
      const fileContent = buffer.toString('utf-8');

      // Process file based on type
      if (originalname.endsWith('.csv') || mimetype === 'text/csv') {
        processedData = processCSV(fileContent, originalname);
      } else if (originalname.endsWith('.tsv') || mimetype === 'text/tab-separated-values') {
        processedData = processTSV(fileContent, originalname);
      } else if (originalname.endsWith('.xlsx') || originalname.endsWith('.xls')) {
        processedData = processExcel(buffer, originalname);
      } else if (originalname.endsWith('.json') || mimetype === 'application/json') {
        processedData = processJSON(fileContent, originalname);
      } else if (originalname.endsWith('.xml') || mimetype === 'application/xml') {
        processedData = processXML(fileContent, originalname);
      } else {
        return res.status(400).json({ message: "Unsupported file type" });
      }

      // Store dataset
      const dataset = await storage.createDataset({
        userId,
        filename: processedData.filename,
        fileType: processedData.fileType,
        data: processedData.data,
        columns: processedData.columns,
        rowCount: processedData.rowCount
      });

      // Consume tokens after successful upload
      await consumeTokens(req as any, res, () => {});
      
      // Broadcast dataset upload to connected clients
      if ((app as any).broadcast) {
        (app as any).broadcast('dataset-uploads', {
          type: 'new_dataset',
          dataset: {
            id: dataset.id,
            filename: dataset.filename,
            fileType: dataset.fileType,
            rowCount: processedData.rowCount
          },
          timestamp: Date.now()
        });
      }
      
      res.json({
        datasetId: dataset.id,
        filename: dataset.filename,
        fileType: dataset.fileType,
        rowCount: processedData.rowCount,
        columns: processedData.columns,
        preview: processedData.data.slice(0, 10)
      });
    } catch (error) {
      console.error("File upload error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to process file" 
      });
    }
  });

  // Get datasets
  app.get("/api/datasets", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const datasets = await storage.getDatasetsByUserId(userId);
      
      res.json(datasets.map(dataset => ({
        id: dataset.id,
        filename: dataset.filename,
        fileType: dataset.fileType,
        rowCount: Array.isArray(dataset.data) ? dataset.data.length : 0,
        uploadedAt: dataset.uploadedAt
      })));
    } catch (error) {
      console.error("Get datasets error:", error);
      res.status(500).json({ message: "Failed to fetch datasets" });
    }
  });

  // Get specific dataset
  app.get("/api/datasets/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const dataset = await storage.getDataset(req.params.id);
      
      if (!dataset || dataset.userId !== userId) {
        return res.status(404).json({ message: "Dataset not found" });
      }

      res.json({
        id: dataset.id,
        filename: dataset.filename,
        fileType: dataset.fileType,
        data: dataset.data,
        columns: dataset.columns,
        rowCount: Array.isArray(dataset.data) ? dataset.data.length : 0,
        uploadedAt: dataset.uploadedAt
      });
    } catch (error) {
      console.error("Get dataset error:", error);
      res.status(500).json({ message: "Failed to fetch dataset" });
    }
  });

  // Analyze data with AI
  app.post("/api/analyze", isAuthenticated, checkTokenLimit('query') as any, async (req: any, res) => {
    try {
      const { datasetId, query, context } = req.body;
      const userId = req.user.claims.sub;

      if (!datasetId || !query) {
        return res.status(400).json({ message: "Dataset ID and query are required" });
      }

      const dataset = await storage.getDataset(datasetId);
      if (!dataset || dataset.userId !== userId) {
        return res.status(404).json({ message: "Dataset not found" });
      }

      const analysis = await analyzeDataWithAI({
        query,
        data: dataset.data as any[],
        columns: (dataset.columns as any[]).map(col => col.name),
        context
      });

      // Store the insight
      const insight = await storage.createInsight({
        datasetId,
        userId,
        query,
        response: analysis,
        visualizations: analysis.visualizations
      });

      // Consume tokens after successful analysis
      await consumeTokens(req as any, res, () => {});
      
      res.json({
        insightId: insight.id,
        ...analysis
      });
    } catch (error) {
      console.error("Analysis error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to analyze data" 
      });
    }
  });

  // Chat endpoint for conversational analysis
  app.post("/api/chat", isAuthenticated, checkTokenLimit('query') as any, async (req: any, res) => {
    try {
      const { datasetId, message, conversationId } = req.body;
      const userId = req.user.claims.sub;

      if (!datasetId || !message) {
        return res.status(400).json({ message: "Dataset ID and message are required" });
      }

      const dataset = await storage.getDataset(datasetId);
      if (!dataset || dataset.userId !== userId) {
        return res.status(404).json({ message: "Dataset not found" });
      }

      let conversation;
      if (conversationId) {
        conversation = await storage.getConversation(conversationId);
        if (conversation && conversation.userId !== userId) {
          return res.status(404).json({ message: "Conversation not found" });
        }
      }

      if (!conversation) {
        conversation = await storage.createConversation({
          datasetId,
          userId,
          messages: []
        });
      }

      // Add user message
      const messages = Array.isArray(conversation.messages) ? [...conversation.messages] : [];
      messages.push({
        id: Date.now().toString(),
        role: 'user',
        content: message,
        timestamp: new Date()
      });

      // Get AI response
      const analysis = await analyzeDataWithAI({
        query: message,
        data: dataset.data as any[],
        columns: (dataset.columns as any[]).map(col => col.name),
        context: messages.length > 2 ? "Previous conversation context included" : undefined
      });

      // Add AI response
      messages.push({
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: analysis.insights,
        timestamp: new Date(),
        visualizations: analysis.visualizations
      });

      // Update conversation
      await storage.updateConversation(conversation.id, messages);

      // Consume tokens after successful chat
      await consumeTokens(req as any, res, () => {});
      

      
      res.json({
        conversationId: conversation.id,
        message: {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: analysis.insights,
          timestamp: new Date(),
          visualizations: analysis.visualizations
        },
        followUpQuestions: analysis.followUpQuestions
      });
    } catch (error) {
      console.error("Chat error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to process chat message" 
      });
    }
  });

  // Get conversation
  app.get("/api/conversations/:id", async (req, res) => {
    try {
      const conversation = await storage.getConversation(req.params.id);
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }

      res.json(conversation);
    } catch (error) {
      console.error("Get conversation error:", error);
      res.status(500).json({ message: "Failed to fetch conversation" });
    }
  });

  // Get all conversations for a user
  app.get("/api/conversations", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversations = await storage.getConversations(userId);
      res.json(conversations);
    } catch (error) {
      console.error("Get conversations error:", error);
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });



  // Get visualizations for user
  app.get("/api/visualizations", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const insights = await storage.getInsights(userId);
      
      // Get all conversations with visualizations
      const conversations = await storage.getConversations(userId);
      const visualizations: any[] = [];
      
      conversations.forEach(conv => {
        if (conv.messages && Array.isArray(conv.messages)) {
          conv.messages.forEach((msg: any, index: number) => {
            if (msg.role === 'assistant' && msg.visualizations && msg.visualizations.length > 0) {
              const userMsg = conv.messages[index - 1];
              msg.visualizations.forEach((viz: any, vizIndex: number) => {
                visualizations.push({
                  id: `${conv.id}-${index}-${vizIndex}`,
                  title: viz.title || userMsg?.content?.substring(0, 50) || 'Untitled Visualization',
                  type: viz.type || 'chart',
                  datasetId: conv.datasetId,
                  createdAt: conv.createdAt,
                  visualization: viz,
                  conversationId: conv.id,
                  query: userMsg?.content || 'Unknown query'
                });
              });
            }
          });
        }
      });
      
      res.json(visualizations);
    } catch (error) {
      console.error("Get visualizations error:", error);
      res.status(500).json({ message: "Failed to fetch visualizations" });
    }
  });



  // Generate visualization
  app.post("/api/visualize", isAuthenticated, checkTokenLimit('visualization') as any, async (req: any, res) => {
    try {
      const { datasetId, chartType, title } = req.body;
      const userId = req.user.claims.sub;

      if (!datasetId || !chartType) {
        return res.status(400).json({ message: "Dataset ID and chart type are required" });
      }

      const dataset = await storage.getDataset(datasetId);
      if (!dataset || dataset.userId !== userId) {
        return res.status(404).json({ message: "Dataset not found" });
      }

      const visualization = await generateVisualization(
        dataset.data as any[],
        (dataset.columns as any[]).map(col => col.name),
        chartType,
        title || `${chartType} Chart`
      );

      // Consume tokens after successful visualization
      await consumeTokens(req as any, res, () => {});
      
      res.json(visualization);
    } catch (error) {
      console.error("Visualization error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate visualization" 
      });
    }
  });

  // Get insights for a dataset
  app.get("/api/datasets/:id/insights", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const dataset = await storage.getDataset(req.params.id);
      
      if (!dataset || dataset.userId !== userId) {
        return res.status(404).json({ message: "Dataset not found" });
      }
      
      const insights = await storage.getInsightsByDatasetId(req.params.id);
      res.json(insights);
    } catch (error) {
      console.error("Get insights error:", error);
      res.status(500).json({ message: "Failed to fetch insights" });
    }
  });

  // Enterprise-only routes
  app.get("/api/enterprise/team-stats", async (req, res) => {
    try {
      // Check if user has enterprise plan
      const userId = "default-user"; // In production, get from session/auth
      const userStats = await simpleBillingService.getUserUsageStats(userId);
      
      if (userStats.user.planType !== 'enterprise') {
        return res.status(403).json({ error: "Enterprise plan required" });
      }

      // Mock team stats - in production, this would query the database
      const teamStats = {
        totalMembers: 12,
        activeMembers: 8,
        totalTokensUsed: 2847,
        totalDatasets: 43,
        topUsers: [
          { id: "1", name: "Alice Johnson", tokensUsed: 450, datasetsCreated: 8 },
          { id: "2", name: "Bob Smith", tokensUsed: 380, datasetsCreated: 6 },
          { id: "3", name: "Carol Davis", tokensUsed: 320, datasetsCreated: 7 },
          { id: "4", name: "David Wilson", tokensUsed: 290, datasetsCreated: 5 }
        ],
        monthlyUsage: [
          { month: "December 2024", tokens: 2847, queries: 1423 },
          { month: "November 2024", tokens: 2534, queries: 1267 },
          { month: "October 2024", tokens: 2198, queries: 1099 },
          { month: "September 2024", tokens: 1876, queries: 938 }
        ]
      };

      res.json(teamStats);
    } catch (error) {
      console.error("Team stats error:", error);
      res.status(500).json({ error: "Failed to fetch team statistics" });
    }
  });

  app.post("/api/enterprise/white-label", async (req, res) => {
    try {
      // Check if user has enterprise plan
      const userId = "default-user"; // In production, get from session/auth
      const userStats = await simpleBillingService.getUserUsageStats(userId);
      
      if (userStats.user.planType !== 'enterprise') {
        return res.status(403).json({ error: "Enterprise plan required" });
      }

      const config = req.body;
      
      // In production, save to database
      // await storage.saveWhiteLabelConfig(userId, config);
      
      res.json({ success: true, message: "White-label configuration saved" });
    } catch (error) {
      console.error("White-label config error:", error);
      res.status(500).json({ error: "Failed to save configuration" });
    }
  });

  app.get("/api/enterprise/white-label", async (req, res) => {
    try {
      // Check if user has enterprise plan
      const userId = "default-user"; // In production, get from session/auth
      const userStats = await simpleBillingService.getUserUsageStats(userId);
      
      if (userStats.user.planType !== 'enterprise') {
        return res.status(403).json({ error: "Enterprise plan required" });
      }

      // In production, fetch from database
      const config = {
        companyName: "DataDialogue AI",
        logoUrl: "",
        primaryColor: "#3b82f6",
        secondaryColor: "#64748b",
        customDomain: "",
        welcomeMessage: "Welcome to your data analytics platform",
        supportEmail: "support@company.com",
        customCss: ""
      };

      res.json(config);
    } catch (error) {
      console.error("White-label config fetch error:", error);
      res.status(500).json({ error: "Failed to fetch configuration" });
    }
  });

  // Billing endpoints
  app.get("/api/billing/usage", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const usage = await simpleBillingService.getUserUsageStats(userId);
      res.json(usage);
    } catch (error) {
      console.error("Get usage error:", error);
      res.status(500).json({ message: "Failed to fetch usage statistics" });
    }
  });

  // Get pending charges for pay-as-you-go users
  app.get("/api/billing/pending", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const pendingCharges = await simpleBillingService.getPendingCharges(userId);
      res.json({ pendingCharges });
    } catch (error) {
      console.error("Error fetching pending charges:", error);
      res.status(500).json({ message: "Failed to fetch pending charges" });
    }
  });

  app.post("/api/billing/upgrade", isAuthenticated, async (req: any, res) => {
    try {
      const { planType } = req.body;
      const userId = req.user.claims.sub;

      if (!planType || !['free', 'flat', 'payg', 'enterprise'].includes(planType)) {
        return res.status(400).json({ message: "Invalid plan type" });
      }

      const result = await simpleBillingService.upgradePlan(userId, planType);
      
      if (!result.success) {
        return res.status(400).json({ message: result.error });
      }

      res.json({ success: true, message: `Successfully upgraded to ${planType} plan` });
    } catch (error) {
      console.error("Upgrade error:", error);
      res.status(500).json({ message: "Failed to upgrade plan" });
    }
  });

  // Billing simulation endpoint for demo
  app.post("/api/billing/simulate", isAuthenticated, async (req: any, res) => {
    try {
      const { action } = req.body;
      const userId = req.user.claims.sub;

      if (!action || !['upload', 'query', 'visualization'].includes(action)) {
        return res.status(400).json({ error: "Invalid action type" });
      }

      // Check token limit
      const limitCheck = await simpleBillingService.checkTokenLimit(userId, action);
      if (!limitCheck.allowed) {
        return res.status(limitCheck.upgradeRequired ? 402 : 429).json({
          error: limitCheck.reason,
          upgradeRequired: limitCheck.upgradeRequired
        });
      }

      // Consume tokens
      const result = await simpleBillingService.consumeTokens(userId, action);
      res.json(result);
    } catch (error) {
      console.error("Simulation error:", error);
      res.status(500).json({ error: "Failed to simulate action" });
    }
  });

  // Reset billing data for demo purposes
  app.post("/api/billing/reset", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const result = await simpleBillingService.resetUserBilling(userId);
      
      if (result.success) {
        res.json({ success: true, message: "Billing data reset successfully" });
      } else {
        res.status(400).json({ message: result.error });
      }
    } catch (error) {
      console.error("Reset error:", error);
      res.status(500).json({ message: "Failed to reset billing data" });
    }
  });

  // Stripe Payment Routes
  
  // Create subscription for paid plans
  app.post("/api/stripe/create-subscription", isAuthenticated, async (req: any, res) => {
    try {
      const { planType, email, name } = req.body;
      const userId = req.user.claims.sub;

      if (!planType || !['flat', 'enterprise'].includes(planType)) {
        return res.status(400).json({ error: "Invalid plan type for subscription" });
      }

      const plan = PRICING_PLANS[planType as keyof typeof PRICING_PLANS];
      
      // Create or retrieve customer
      let customer;
      try {
        const customers = await stripe.customers.list({
          email: email || `${userId}@datadialogue.ai`,
          limit: 1
        });
        
        if (customers.data.length > 0) {
          customer = customers.data[0];
        } else {
          customer = await stripe.customers.create({
            email: email || `${userId}@datadialogue.ai`,
            name: name || `User ${userId}`,
            metadata: { userId }
          });
        }
      } catch (error) {
        console.error("Customer creation error:", error);
        return res.status(500).json({ error: "Failed to create customer" });
      }

      // Create subscription
      try {
        // First create a product
        const product = await stripe.products.create({
          name: plan.name,
          description: `${plan.tokens} tokens per month`
        });

        // Then create a price for the product
        const price = await stripe.prices.create({
          currency: 'usd',
          unit_amount: plan.price * 100, // Convert to cents
          recurring: { interval: 'month' },
          product: product.id,
        });

        // Create a setup intent first for payment method collection
        const setupIntent = await stripe.setupIntents.create({
          customer: customer.id,
          payment_method_types: ['card'],
          usage: 'off_session',
        });

        // Store subscription details for later completion
        res.json({
          clientSecret: setupIntent.client_secret,
          customerId: customer.id,
          priceId: price.id,
          setupIntentId: setupIntent.id
        });


      } catch (error) {
        console.error("Subscription creation error:", error);
        res.status(500).json({ error: "Failed to create subscription" });
      }
    } catch (error) {
      console.error("Stripe subscription error:", error);
      res.status(500).json({ error: "Payment processing failed" });
    }
  });

  // Create payment intent for pay-as-you-go tokens
  app.post("/api/stripe/create-payment-intent", async (req, res) => {
    try {
      const { amount, tokens, email } = req.body;
      const userId = "default-user"; // In production, get from session/auth

      if (!amount || !tokens || amount < 1) {
        return res.status(400).json({ error: "Invalid payment amount" });
      }

      // Create or retrieve customer
      let customer;
      try {
        const customers = await stripe.customers.list({
          email: email || `${userId}@datadialogue.ai`,
          limit: 1
        });
        
        if (customers.data.length > 0) {
          customer = customers.data[0];
        } else {
          customer = await stripe.customers.create({
            email: email || `${userId}@datadialogue.ai`,
            name: `User ${userId}`,
            metadata: { userId }
          });
        }
      } catch (error) {
        console.error("Customer creation error:", error);
        return res.status(500).json({ error: "Failed to create customer" });
      }

      // Create payment intent
      try {
        const paymentIntent = await stripe.paymentIntents.create({
          amount: Math.round(amount * 100), // Convert to cents
          currency: 'usd',
          customer: customer.id,
          description: `Purchase ${tokens} tokens for DataDialogue AI`,
          metadata: {
            userId,
            tokens: tokens.toString(),
            type: 'token_purchase'
          },
          automatic_payment_methods: { enabled: true },
        });

        res.json({
          clientSecret: paymentIntent.client_secret,
          paymentIntentId: paymentIntent.id
        });
      } catch (error) {
        console.error("Payment intent creation error:", error);
        res.status(500).json({ error: "Failed to create payment intent" });
      }
    } catch (error) {
      console.error("Stripe payment intent error:", error);
      res.status(500).json({ error: "Payment processing failed" });
    }
  });

  // Webhook endpoint for Stripe events
  app.post("/api/stripe/webhook", async (req, res) => {
    try {
      const sig = req.headers['stripe-signature'];
      let event;

      try {
        event = stripe.webhooks.constructEvent(req.body, sig as string, process.env.STRIPE_WEBHOOK_SECRET || '');
      } catch (err) {
        console.error('Webhook signature verification failed:', err);
        return res.status(400).send(`Webhook Error: ${err}`);
      }

      // Handle the event
      switch (event.type) {
        case 'invoice.payment_succeeded':
          const invoice = event.data.object;
          console.log('Payment succeeded for invoice:', invoice.id);
          
          // Update user's plan and token allocation
          if ((invoice as any).subscription) {
            const subscription = await stripe.subscriptions.retrieve((invoice as any).subscription as string);
            const customerId = subscription.customer as string;
            const customer = await stripe.customers.retrieve(customerId);
            
            if (customer && !customer.deleted) {
              const userId = customer.metadata?.userId || "default-user";
              
              // Determine plan type based on amount
              let planType = 'free';
              const amount = invoice.amount_paid / 100; // Convert from cents
              
              if (amount === PRICING_PLANS.flat.price) {
                planType = 'flat';
              } else if (amount === PRICING_PLANS.enterprise.price) {
                planType = 'enterprise';
              }
              
              // Update user's plan
              await simpleBillingService.upgradePlan(userId, planType as 'free' | 'flat' | 'payg' | 'enterprise');
              console.log(`Updated user ${userId} to ${planType} plan`);
            }
          }
          break;

        case 'payment_intent.succeeded':
          const paymentIntent = event.data.object;
          console.log('Payment intent succeeded:', paymentIntent.id);
          
          // Handle token purchases
          if (paymentIntent.metadata?.type === 'token_purchase') {
            const userId = paymentIntent.metadata.userId || "default-user";
            const tokens = parseInt(paymentIntent.metadata.tokens || '0');
            
            // Add tokens to user's account (this would update the database in production)
            console.log(`Added ${tokens} tokens to user ${userId}`);
          }
          break;

        case 'customer.subscription.deleted':
          const subscription = event.data.object;
          const customer = await stripe.customers.retrieve(subscription.customer as string);
          
          if (customer && !customer.deleted) {
            const userId = customer.metadata?.userId || "default-user";
            
            // Downgrade user to free plan
            await simpleBillingService.upgradePlan(userId, 'free');
            console.log(`Downgraded user ${userId} to free plan`);
          }
          break;

        default:
          console.log(`Unhandled event type ${event.type}`);
      }

      res.json({ received: true });
    } catch (error) {
      console.error("Webhook error:", error);
      res.status(500).json({ error: "Webhook processing failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
