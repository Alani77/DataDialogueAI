import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, Upload, MessageSquare, BarChart3 } from "lucide-react";
import { TOKEN_COSTS, PRICING_PLANS } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function BillingDemo() {
  const [isSimulating, setIsSimulating] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const simulateActionMutation = useMutation({
    mutationFn: async (action: keyof typeof TOKEN_COSTS) => {
      // Simulate token consumption by calling the API
      const response = await fetch('/api/billing/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to simulate action');
      }
      
      return response.json();
    },
    onSuccess: (data, action) => {
      toast({
        title: "Action simulated!",
        description: `${action} consumed ${TOKEN_COSTS[action]} tokens${data.cost ? ` ($${data.cost.toFixed(4)})` : ''}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/billing/usage'] });
    },
    onError: (error: Error) => {
      if (error.message.includes('upgradeRequired')) {
        toast({
          title: "Upgrade required",
          description: "You've reached your free tier limit. Please upgrade to continue.",
          variant: "destructive",
        });
        window.dispatchEvent(new CustomEvent('showUpgradeModal'));
      } else {
        toast({
          title: "Limit exceeded",
          description: error.message,
          variant: "destructive",
        });
      }
    },
  });

  const simulateHeavyUsage = async () => {
    setIsSimulating(true);
    
    // Simulate multiple actions to demonstrate limits
    const actions: (keyof typeof TOKEN_COSTS)[] = ['upload', 'query', 'query', 'visualization', 'upload'];
    
    for (const action of actions) {
      try {
        await simulateActionMutation.mutateAsync(action);
        await new Promise(resolve => setTimeout(resolve, 500)); // Small delay between actions
      } catch (error) {
        break; // Stop if we hit a limit
      }
    }
    
    setIsSimulating(false);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-primary" />
          Billing System Demo
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => simulateActionMutation.mutate('upload')}
            disabled={simulateActionMutation.isPending}
            className="flex items-center gap-2"
          >
            <Upload className="w-4 h-4" />
            Simulate Upload
            <Badge variant="secondary" className="ml-1">
              {TOKEN_COSTS.upload} tokens
            </Badge>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => simulateActionMutation.mutate('query')}
            disabled={simulateActionMutation.isPending}
            className="flex items-center gap-2"
          >
            <MessageSquare className="w-4 h-4" />
            Simulate Query
            <Badge variant="secondary" className="ml-1">
              {TOKEN_COSTS.query} tokens
            </Badge>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => simulateActionMutation.mutate('visualization')}
            disabled={simulateActionMutation.isPending}
            className="flex items-center gap-2"
          >
            <BarChart3 className="w-4 h-4" />
            Simulate Chart
            <Badge variant="secondary" className="ml-1">
              {TOKEN_COSTS.visualization} tokens
            </Badge>
          </Button>
          
          <Button
            variant="destructive"
            size="sm"
            onClick={simulateHeavyUsage}
            disabled={isSimulating || simulateActionMutation.isPending}
            className="flex items-center gap-2"
          >
            <Zap className="w-4 h-4" />
            Heavy Usage
          </Button>
        </div>

        <div className="text-xs text-slate-600 dark:text-slate-400 space-y-1">
          <p><strong>Demo Instructions:</strong></p>
          <p>• Click buttons to simulate token consumption</p>
          <p>• Free tier has 5 tokens/month limit</p>
          <p>• "Heavy Usage" will trigger upgrade prompt</p>
          <p>• Token meter updates in real-time</p>
        </div>

        <div className="pt-2 border-t border-slate-200 dark:border-slate-700">
          <h4 className="text-sm font-medium mb-2">Pricing Plans</h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            {Object.entries(PRICING_PLANS).map(([key, plan]) => (
              <div key={key} className="p-2 bg-slate-50 dark:bg-slate-800 rounded">
                <div className="font-medium capitalize">{key}</div>
                <div className="text-slate-600 dark:text-slate-400">
                  ${plan.price}/mo • {plan.tokens} tokens
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}