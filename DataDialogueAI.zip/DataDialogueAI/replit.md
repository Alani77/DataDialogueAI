# DataDialogue AI - Intelligent Data Analytics Platform

## Overview

DataDialogue AI is a fully operational modern web application that enables users to upload, analyze, and visualize data using AI-powered insights. The platform provides an intuitive interface for data exploration through natural language queries, automated visualizations, and comprehensive analytics capabilities. Built as a full-stack TypeScript application, it combines a React frontend with an Express backend, featuring real-time chat interactions and intelligent data processing powered by GPT-4.

## Recent Updates (August 1, 2025)
- ✅ Completed full MVP implementation with all core features working
- ✅ Fixed PapaParse import issues for server-side CSV processing 
- ✅ Resolved all TypeScript compilation errors
- ✅ Successfully tested file upload (CSV, TSV, Excel, JSON, XML)
- ✅ Verified AI chat integration with OpenAI GPT-4 
- ✅ Confirmed data visualization generation with Plotly.js
- ✅ Validated end-to-end workflow from upload to AI insights
- ✅ **Added PostgreSQL database for persistent data storage**
- ✅ **Implemented DatabaseStorage with Drizzle ORM**
- ✅ **Verified data persistence for datasets, conversations, and insights**
- ✅ **Added comprehensive dark mode functionality with theme toggle**
- ✅ **Updated all UI components to support light/dark theme switching**
- ✅ **Implemented theme persistence with localStorage**
- ✅ **Renamed platform from "DataFlow AI" to "DataDialogue AI"**
- ✅ **Updated branding across all UI components and documentation**
- ✅ **Implemented comprehensive token-based billing system**
- ✅ **Added Free, Flat Subscription, Pay-As-You-Go, and Enterprise pricing tiers**
- ✅ **Created token usage tracking and limits enforcement**
- ✅ **Built token meter component with real-time usage display**
- ✅ **Added upgrade modal with plan selection and pricing details**
- ✅ **Integrated billing middleware with route protection**
- ✅ **Increased token limits across all tiers for production readiness**
- ✅ **Enhanced daily usage limits and file size restrictions**
- ✅ **Updated free tier to 20 tokens per month for sustainable usage**
- ✅ **Increased free tier daily limit from 5 to 10 tokens for better user experience**
- ✅ **Fixed database schema issues with missing row_count column**
- ✅ **Removed billing demo component from main dashboard interface**
- ✅ **Implemented full Replit authentication system with OpenID Connect**
- ✅ **Added beautiful landing page for unauthenticated users**
- ✅ **Created functional sidebar navigation with dedicated views**
- ✅ **Implemented Upload, Visualizations, Reports, and History sections**
- ✅ **Updated database schema for Replit Auth user management**
- ✅ **Added authentication routing with protected and public pages**
- ✅ **Created interactive demo video modal for "Watch Demo" button**
- ✅ **Built step-by-step product walkthrough with feature highlights**
- ✅ **Fixed critical data isolation bug - removed all hardcoded preview data**
- ✅ **Updated all API endpoints to use authenticated user IDs instead of fallback values**
- ✅ **Replaced mock data in sidebar views with proper authenticated API calls**
- ✅ **Added missing storage methods for user-specific data retrieval**
- ✅ **Verified database shows proper user data isolation working correctly**
- ✅ **Implemented comprehensive button functionality across all sidebar views**
- ✅ **Added interactive features: share dialogs, search, edit modals, download capabilities**
- ✅ **Redesigned dashboard layout for improved chat accessibility and prominence**
- ✅ **Enhanced chat interface with visual improvements and sticky positioning**
- ✅ **Created responsive 3-column layout with dedicated chat area on large screens**
- ✅ **Removed live notifications feature completely including WebSocket components**
- ✅ **Eliminated real-time indicators, dashboard streaming, and notification system**
- ✅ **Cleaned up server-side broadcast functionality and WebSocket connections** 
- ✅ **Implemented billing restrictions for PDF export functionality**
- ✅ **Added premium feature gates preventing free tier users from downloading visualizations**
- ✅ **Updated UI to show "Premium" labels on restricted export buttons for free users**
- ✅ **Removed History page and associated API endpoints**
- ✅ **Cleaned up navigation to focus on core features: Dashboard, Upload, Visualizations, Reports**
- ✅ **Removed Shared Reports page and API endpoint completely**
- ✅ **Updated navigation to focus on core features: Dashboard, Upload, and Visualizations**

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Library**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with CSS variables for theming support
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation
- **Charts**: Plotly.js for interactive data visualizations

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with structured route handling
- **File Processing**: Multi-format support (CSV, TSV, Excel, JSON, XML) using specialized parsers
- **Storage Layer**: Abstracted storage interface with in-memory implementation for development

### Data Processing Pipeline
- **File Upload**: Multer middleware for handling multipart form data
- **Format Detection**: Automatic file type detection and appropriate parser selection
- **Data Transformation**: Column type inference and data normalization
- **Storage**: Structured dataset storage with metadata tracking

### AI Integration
- **Provider**: OpenAI GPT-4o for natural language processing
- **Capabilities**: Data analysis, insight generation, and visualization recommendations
- **Chat Interface**: Conversational AI for interactive data exploration
- **Context Management**: Maintains conversation history and dataset context

### Database Schema
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Tables**: Users, datasets, conversations, and insights with proper relationships
- **Migrations**: Automated schema management through Drizzle Kit
- **Validation**: Zod schemas for type-safe data handling

### Development Environment
- **Hot Reload**: Vite development server with HMR support
- **Error Handling**: Runtime error overlay for development debugging
- **Build Process**: Separate client and server build pipelines
- **TypeScript**: Strict type checking with path mapping for clean imports

### Billing System
- **Token-Based Pricing**: Consumption-based billing model with four production-ready plan tiers
- **Usage Tracking**: Real-time token consumption monitoring for uploads (1), queries (2), and visualizations (1)
- **Limit Enforcement**: Automatic usage validation with generous production limits
- **Plan Management**: In-memory billing service with upgrade capabilities (database integration pending)
- **UI Components**: Token meter, usage statistics, upgrade modal, and billing demo for testing
- **Production Limits**: Free (20 tokens), Flat ($20/150 tokens), Pay-As-You-Go ($0.02/token), Enterprise ($180/1500 tokens)
- **Enhanced Quotas**: Tiered daily limits (5 free, 20 flat, 100 payg, 75 enterprise), 50MB file size limit, 30 requests/minute rate limit

## External Dependencies

### Database
- **PostgreSQL**: Primary database using Neon serverless PostgreSQL
- **Connection**: Environment-based connection string configuration
- **Session Storage**: PostgreSQL-backed session management with connect-pg-simple

### AI Services
- **OpenAI API**: GPT-4o model for natural language processing and data analysis
- **Authentication**: API key-based authentication with environment variable configuration

### File Processing Libraries
- **PapaParse**: CSV and TSV parsing with automatic type detection
- **SheetJS (XLSX)**: Excel file processing for .xlsx and .xls formats
- **Built-in Parsers**: JSON and XML processing using native JavaScript capabilities

### UI and Visualization
- **Radix UI**: Comprehensive component library for accessible UI elements
- **Plotly.js**: Interactive charting library for data visualizations
- **React Dropzone**: File upload interface with drag-and-drop support
- **Embla Carousel**: Touch-friendly carousel component

### Development Tools
- **Vite**: Fast build tool with plugin ecosystem
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Tailwind CSS integration
- **Replit Integration**: Development environment optimizations for Replit platform