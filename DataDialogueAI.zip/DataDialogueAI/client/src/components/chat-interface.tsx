import { useState, useRef, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Bot, User, Send, Loader2, BarChart3, Download, FileText, MessageSquare, FileImage } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import Plot from "react-plotly.js";
import { cn } from "@/lib/utils";

interface ChatInterfaceProps {
  datasetId: string;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  visualizations?: any[];
}

interface ChatResponse {
  conversationId: string;
  message: ChatMessage;
  followUpQuestions: string[];
}

export default function ChatInterface({ datasetId }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [followUpQuestions, setFollowUpQuestions] = useState<string[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get user billing information
  const { data: billingData } = useQuery({
    queryKey: ['/api/billing/usage'],
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Load existing conversation for this dataset
  const { data: existingConversations, isLoading: conversationsLoading } = useQuery({
    queryKey: ['/api/conversations', datasetId],
    queryFn: async () => {
      const response = await fetch('/api/conversations');
      if (!response.ok) throw new Error('Failed to fetch conversations');
      return response.json();
    },
    enabled: !!datasetId
  });

  useEffect(() => {
    if (conversationsLoading) return;
    
    // Find existing conversation for this dataset
    const datasetConversation = existingConversations?.find(
      (conv: any) => conv.datasetId === datasetId
    );
    
    if (datasetConversation && Array.isArray(datasetConversation.messages)) {
      // Load existing conversation
      setConversationId(datasetConversation.id);
      const conversationMessages = datasetConversation.messages.map((msg: any) => ({
        id: msg.id,
        role: msg.role,
        content: msg.content,
        timestamp: new Date(msg.timestamp),
        visualizations: msg.visualizations
      }));
      setMessages(conversationMessages);
    } else {
      // Add welcome message for new conversations
      const welcomeMessage: ChatMessage = {
        id: 'welcome',
        role: 'assistant',
        content: "Hello! I'm your AI data assistant. Upload your data and ask me anything about it. I can help you analyze trends, create visualizations, and discover insights.",
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
      setConversationId(null);
    }
  }, [datasetId, existingConversations, conversationsLoading]);

  const chatMutation = useMutation({
    mutationFn: async (message: string): Promise<ChatResponse> => {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          datasetId,
          message,
          conversationId
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to send message');
      }

      return response.json();
    },
    onSuccess: (data) => {
      setConversationId(data.conversationId);
      setMessages(prev => [...prev, data.message]);
      setFollowUpQuestions(data.followUpQuestions || []);
      
      // Invalidate conversations query to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/conversations', datasetId] });
    },
    onError: (error: Error) => {
      toast({
        title: "Chat error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!inputValue.trim() || chatMutation.isPending) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    chatMutation.mutate(inputValue);
    setInputValue("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSuggestedQuestion = (question: string) => {
    setInputValue(question);
  };

  const exportVisualizationsAsPNG = async () => {
    console.log('Starting visualization PNG export...');
    
    // Check if user is on free tier
    if (billingData?.user?.planType === 'free') {
      toast({
        title: "Upgrade Tier Feature",
        description: "Visualization export is available for paid plans only. Upgrade to access this feature.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      const timestamp = new Date().toISOString().split('T')[0];
      const timeStr = new Date().toLocaleTimeString().replace(/:/g, '-');
      
      // Find all visualizations in the conversation
      const visualizations = messages
        .filter(m => m.visualizations && m.visualizations.length > 0)
        .flatMap(m => {
          const query = messages[messages.indexOf(m) - 1]?.content || 'Unknown query';
          return m.visualizations!.map(viz => ({ ...viz, query, timestamp: m.timestamp }));
        });

      console.log('Found visualizations:', visualizations.length);
      
      if (visualizations.length === 0) {
        toast({
          title: "No Visualizations",
          description: "This conversation contains no visualizations to export.",
          variant: "destructive",
        });
        return;
      }

      // Create container for all PNG exports
      const exportPromises: Promise<void>[] = [];
      let exportCount = 0;

      // Process each visualization as separate PNG
      for (let i = 0; i < visualizations.length; i++) {
        const viz = visualizations[i];
        
        if (viz.data && viz.layout) {
          const exportPromise = (async () => {
            try {
            
              // Create temporary container for chart
              const tempContainer = document.createElement('div');
              tempContainer.style.width = '1200px';
              tempContainer.style.height = '800px';
              tempContainer.style.position = 'absolute';
              tempContainer.style.left = '-9999px';
              tempContainer.style.backgroundColor = '#ffffff';
              tempContainer.id = `temp-viz-chart-${Date.now()}-${i}`;
              document.body.appendChild(tempContainer);
              
              const plotData = Array.isArray(viz.data) ? viz.data : [viz.data];
              const plotLayout = {
                ...viz.layout,
                width: 1200,
                height: 800,
                title: { text: viz.title, font: { size: 24 } },
                margin: { t: 80, r: 60, b: 80, l: 80 },
                paper_bgcolor: '#ffffff',
                plot_bgcolor: '#ffffff'
              };
            
              // Render chart
              await new Promise((resolve, reject) => {
                import('plotly.js-dist').then((Plotly: any) => {
                  Plotly.newPlot(tempContainer, plotData, plotLayout, {
                    displayModeBar: false,
                    staticPlot: true
                  }).then(resolve).catch(reject);
                });
              });
              
              // Wait for rendering
              await new Promise(resolve => setTimeout(resolve, 1000));
              
              // Capture chart as PNG
              const canvas = await html2canvas(tempContainer, {
                width: 1200,
                height: 800,
                scale: 2,
                backgroundColor: '#ffffff'
              });
              
              // Download PNG file
              const link = document.createElement('a');
              const vizTitle = viz.title?.replace(/[^a-zA-Z0-9]/g, '-') || `visualization-${i + 1}`;
              link.download = `dataDialogue-${vizTitle}-${timestamp}-${timeStr}.png`;
              link.href = canvas.toDataURL('image/png');
              link.click();
              
              exportCount++;
              
              // Clean up
              document.body.removeChild(tempContainer);
            } catch (error) {
              console.error('Error exporting visualization:', error);
            }
          })();
          
          exportPromises.push(exportPromise);
        }
      }
      
      // Wait for all exports to complete
      await Promise.all(exportPromises);
      
      toast({
        title: "PNG Export Complete",
        description: `${exportCount} visualizations exported as PNG files.`,
      });
      
    } catch (error) {
      console.error('Visualizations PNG export error:', error);
      toast({
        title: "Export Failed",
        description: "Failed to export visualizations as PNG.",
        variant: "destructive",
      });
    }
  };

  const exportChatAsPDF = async () => {
    console.log('Starting chat PDF export...');
    
    // Check if user is on free tier
    if (billingData?.user?.planType === 'free') {
      toast({
        title: "Upgrade Tier Feature", 
        description: "PDF export with visualizations is available for paid plans only. Upgrade to access this feature.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      const timestamp = new Date().toISOString().split('T')[0];
      const timeStr = new Date().toLocaleTimeString().replace(/:/g, '-');
      
      // Create PDF
      const pdf = new jsPDF('portrait', 'mm', 'a4');
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      let yPosition = 30;
      
      // Add title page
      pdf.setFontSize(20);
      pdf.text('DataDialogue AI - Chat Export', 20, yPosition);
      yPosition += 15;
      
      pdf.setFontSize(12);
      pdf.text(`Export Date: ${new Date().toLocaleString()}`, 20, yPosition);
      yPosition += 10;
      pdf.text(`Conversation ID: ${conversationId}`, 20, yPosition);
      yPosition += 10;
      pdf.text(`Total Messages: ${messages.filter(m => m.id !== 'welcome').length}`, 20, yPosition);
      yPosition += 20;
      
      // Process messages
      const chatMessages = messages.filter(m => m.id !== 'welcome');
      
      for (let i = 0; i < chatMessages.length; i++) {
        const message = chatMessages[i];
        
        // Check if we need a new page
        if (yPosition > pageHeight - 40) {
          pdf.addPage();
          yPosition = 20;
        }
        
        // Add message header
        pdf.setFontSize(10);
        const role = message.role === 'user' ? 'YOU' : 'AI ASSISTANT';
        const timestamp = new Date(message.timestamp).toLocaleString();
        pdf.text(`[${timestamp}] ${role}:`, 20, yPosition);
        yPosition += 8;
        
        // Add message content
        pdf.setFontSize(9);
        const lines = pdf.splitTextToSize(message.content, pageWidth - 40);
        pdf.text(lines, 20, yPosition);
        yPosition += lines.length * 4 + 5;
        
        // Add visualizations if present
        if (message.visualizations && message.visualizations.length > 0) {
          for (const viz of message.visualizations) {
            if (viz.data && viz.layout) {
              try {
                // Check if we need a new page for visualization
                if (yPosition > pageHeight - 100) {
                  pdf.addPage();
                  yPosition = 20;
                }
                
                // Create temporary container for chart
                const tempContainer = document.createElement('div');
                tempContainer.style.width = '600px';
                tempContainer.style.height = '400px';
                tempContainer.style.position = 'absolute';
                tempContainer.style.left = '-9999px';
                tempContainer.id = `temp-chat-chart-${Date.now()}-${i}`;
                document.body.appendChild(tempContainer);
                
                const plotData = Array.isArray(viz.data) ? viz.data : [viz.data];
                const plotLayout = {
                  ...viz.layout,
                  width: 600,
                  height: 400,
                  title: { text: viz.title, font: { size: 16 } },
                  margin: { t: 60, r: 50, b: 60, l: 60 }
                };
                
                // Render chart
                await new Promise((resolve, reject) => {
                  import('plotly.js-dist').then((Plotly: any) => {
                    Plotly.newPlot(tempContainer, plotData, plotLayout, {
                      displayModeBar: false,
                      staticPlot: true
                    }).then(resolve).catch(reject);
                  });
                });
                
                // Wait for rendering
                await new Promise(resolve => setTimeout(resolve, 800));
                
                // Capture chart
                const canvas = await html2canvas(tempContainer, {
                  width: 600,
                  height: 400,
                  scale: 1.5,
                  backgroundColor: '#ffffff'
                });
                
                // Add chart to PDF
                const imgWidth = 160;
                const imgHeight = (canvas.height * imgWidth) / canvas.width;
                
                pdf.addImage(canvas.toDataURL('image/jpeg', 0.9), 'JPEG', 20, yPosition, imgWidth, imgHeight);
                yPosition += imgHeight + 10;
                
                // Cleanup
                document.body.removeChild(tempContainer);
                
              } catch (error) {
                console.error('Chart rendering error:', error);
                // Add text placeholder if chart fails
                pdf.setFontSize(9);
                pdf.text(`📊 Visualization: ${viz.title} (${viz.type || 'chart'})`, 25, yPosition);
                yPosition += 6;
              }
            }
          }
        }
        
        yPosition += 5; // Space between messages
      }
      
      // Save PDF
      pdf.save(`dataDialogue-chat-${timestamp}-${timeStr}.pdf`);
      
      toast({
        title: "PDF Export Complete",
        description: "Chat exported as PDF with embedded visualizations.",
      });
      
    } catch (error) {
      console.error('PDF export error:', error);
      toast({
        title: "PDF Export Failed",
        description: "Failed to generate PDF. Please try again.",
        variant: "destructive",
      });
    }
  };

  const exportChat = (type: 'full' | 'text-only' | 'visualizations' | 'pdf') => {
    if (type === 'pdf') {
      exportChatAsPDF();
      return;
    }
    const timestamp = new Date().toISOString().split('T')[0];
    const timeStr = new Date().toLocaleTimeString().replace(/:/g, '-');
    let content = '';
    let filename = '';
    let mimeType = '';

    switch (type) {
      case 'full':
        filename = `dataDialogue-conversation-${timestamp}-${timeStr}.txt`;
        mimeType = 'text/plain';
        
        content = `DataDialogue AI - Full Conversation Export\n`;
        content += `Export Date: ${new Date().toLocaleString()}\n`;
        content += `Conversation ID: ${conversationId}\n`;
        content += `Total Messages: ${messages.filter(m => m.id !== 'welcome').length}\n`;
        content += `\n${'='.repeat(60)}\n\n`;
        
        content += messages
          .filter(m => m.id !== 'welcome')
          .map(m => {
            let msgContent = `[${new Date(m.timestamp).toLocaleString()}] ${m.role === 'user' ? 'YOU' : 'AI ASSISTANT'}:\n`;
            msgContent += `${m.content}\n`;
            
            if (m.visualizations && m.visualizations.length > 0) {
              msgContent += `\n📊 VISUALIZATIONS GENERATED (${m.visualizations.length}):\n`;
              m.visualizations.forEach((viz, i) => {
                msgContent += `  ${i + 1}. ${viz.title} (${viz.type || 'chart'})\n`;
                if (viz.description) msgContent += `     Description: ${viz.description}\n`;
              });
            }
            
            return msgContent;
          })
          .join('\n' + '-'.repeat(40) + '\n\n');
        break;
        
      case 'text-only':
        filename = `dataDialogue-messages-${timestamp}-${timeStr}.md`;
        mimeType = 'text/markdown';
        
        content = `# DataDialogue AI - Chat Messages\n\n`;
        content += `**Export Date:** ${new Date().toLocaleString()}  \n`;
        content += `**Conversation:** ${conversationId}  \n`;
        content += `**Messages:** ${messages.filter(m => m.id !== 'welcome').length}\n\n`;
        content += `---\n\n`;
        
        content += messages
          .filter(m => m.id !== 'welcome')
          .map(m => {
            const role = m.role === 'user' ? '🧑 **You**' : '🤖 **AI Assistant**';
            const time = new Date(m.timestamp).toLocaleString();
            return `## ${role} - ${time}\n\n${m.content}\n`;
          })
          .join('\n---\n\n');
        break;
        
      case 'visualizations':
        filename = `dataDialogue-visualizations-${timestamp}-${timeStr}.csv`;
        mimeType = 'text/csv';
        
        const visualizations = messages
          .filter(m => m.visualizations && m.visualizations.length > 0)
          .flatMap(m => {
            const query = messages[messages.indexOf(m) - 1]?.content || 'Unknown query';
            return m.visualizations!.map(viz => ({
              timestamp: new Date(m.timestamp).toLocaleString(),
              query: query.replace(/"/g, '""'), // Escape quotes for CSV
              title: viz.title?.replace(/"/g, '""') || 'Untitled',
              type: viz.type || 'chart',
              description: viz.description?.replace(/"/g, '""') || '',
              hasData: viz.data ? 'Yes' : 'No'
            }));
          });
        
        if (visualizations.length === 0) {
          content = 'No visualizations found in this conversation.';
          mimeType = 'text/plain';
          filename = `dataDialogue-no-visualizations-${timestamp}.txt`;
        } else {
          // CSV headers
          content = 'Timestamp,Query,Visualization Title,Chart Type,Description,Has Data\n';
          
          // CSV rows
          content += visualizations
            .map(viz => `"${viz.timestamp}","${viz.query}","${viz.title}","${viz.type}","${viz.description}","${viz.hasData}"`)
            .join('\n');
        }
        break;
    }

    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Export Complete",
      description: `Chat exported as ${filename}`,
    });
  };

  const suggestedQuestions = [
    "Show me the correlation between different columns",
    "What are the seasonal patterns in my data?",
    "Create a forecast for the next period",
    "Find outliers in the dataset",
    "Generate a summary report"
  ];

  if (conversationsLoading) {
    return (
      <Card className="h-[600px] bg-white dark:bg-slate-800 border-2 border-primary/20 shadow-lg flex flex-col">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto mb-2" />
            <p className="text-sm text-slate-500 dark:text-slate-400">Loading conversation...</p>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="h-[600px] bg-white dark:bg-slate-800 border-2 border-primary/20 shadow-lg flex flex-col">
      {/* Chat Header */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-700 bg-gradient-to-r from-primary/5 to-primary/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100">AI Data Assistant</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">Ask questions about your data</p>
            </div>
          </div>

        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-slate-300 dark:scrollbar-thumb-slate-600">
        {messages.map((message) => (
          <div
            key={message.id}
            className={cn(
              "flex items-start space-x-3 animate-slide-up",
              message.role === 'user' ? "justify-end" : "justify-start"
            )}
          >
            {message.role === 'assistant' && (
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="w-4 h-4 text-white" />
              </div>
            )}

            <div
              className={cn(
                "rounded-lg p-3 max-w-xs",
                message.role === 'user'
                  ? "bg-primary text-white rounded-tr-none"
                  : "bg-slate-50 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-tl-none"
              )}
            >
              <p className="text-sm whitespace-pre-wrap">{message.content}</p>
              
              {/* Visualizations */}
              {message.visualizations && message.visualizations.length > 0 && (
                <div className="mt-3 space-y-2">
                  {message.visualizations.map((viz, index) => (
                    <Card key={index} className="bg-white">
                      <CardContent className="p-2">
                        <p className="text-xs font-medium text-slate-700 mb-2">{viz.title}</p>
                        <div className="h-32 bg-gradient-to-r from-primary/20 to-secondary/20 rounded flex items-center justify-center overflow-hidden">
                          {viz.data && viz.layout ? (
                            <Plot
                              data={Array.isArray(viz.data) ? viz.data : [viz.data]}
                              layout={{
                                ...viz.layout,
                                width: 260,
                                height: 120,
                                margin: { t: 10, r: 10, b: 20, l: 30 },
                                showlegend: false,
                                paper_bgcolor: 'rgba(0,0,0,0)',
                                plot_bgcolor: 'rgba(0,0,0,0)'
                              }}
                              config={{ displayModeBar: false, staticPlot: true }}
                            />
                          ) : (
                            <div className="text-primary">
                              <BarChart3 className="w-6 h-6" />
                            </div>
                          )}
                        </div>
                        {viz.description && (
                          <p className="text-xs text-slate-500 mt-2">{viz.description}</p>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>

            {message.role === 'user' && (
              <div className="w-8 h-8 bg-slate-300 dark:bg-slate-600 rounded-full flex items-center justify-center flex-shrink-0">
                <User className="w-4 h-4 text-slate-600 dark:text-slate-300" />
              </div>
            )}
          </div>
        ))}

        {/* Loading State */}
        {chatMutation.isPending && (
          <div className="flex items-start space-x-3 animate-slide-up">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center flex-shrink-0">
              <Loader2 className="w-4 h-4 text-white animate-spin" />
            </div>
            <div className="bg-slate-50 dark:bg-slate-700 rounded-lg rounded-tl-none p-3">
              <p className="text-sm text-slate-500 dark:text-slate-400">Analyzing your data...</p>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Questions */}
      {(followUpQuestions.length > 0 || messages.length <= 1) && (
        <div className="p-4 border-t border-slate-200 dark:border-slate-700">
          <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
            {followUpQuestions.length > 0 ? "Follow-up questions:" : "Suggested questions:"}
          </p>
          <div className="space-y-2">
            {(followUpQuestions.length > 0 ? followUpQuestions : suggestedQuestions.slice(0, 3)).map((question, index) => (
              <button
                key={index}
                onClick={() => handleSuggestedQuestion(question)}
                className="w-full text-left px-3 py-2 text-xs bg-slate-50 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-md hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors"
              >
                {question}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Export Section */}
      {messages.length > 1 && (
        <div className="px-4 py-2 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="w-full">
                <Download className="w-4 h-4 mr-2" />
                Export Chat
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Export Chat</DialogTitle>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Choose your preferred export format
                </p>
              </DialogHeader>
              <div className="space-y-4">
                <Button
                  onClick={() => exportChat('full')}
                  className="w-full justify-start"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Export Full Conversation (TXT)
                </Button>
                <Button
                  onClick={() => exportChat('text-only')}
                  variant="outline"
                  className="w-full justify-start"
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Export Chat Messages (MD)
                </Button>
                <Button
                  onClick={() => exportVisualizationsAsPNG()}
                  variant="outline"
                  className="w-full justify-start"
                  disabled={billingData?.user?.planType === 'free'}
                >
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Export Visualizations (PNG)
                  {billingData?.user?.planType === 'free' && (
                    <span className="ml-2 text-xs text-orange-600 dark:text-orange-400">Upgrade Tier</span>
                  )}
                </Button>
                <Button
                  onClick={() => exportChat('pdf')}
                  variant="outline"
                  className="w-full justify-start"
                  disabled={billingData?.user?.planType === 'free'}
                >
                  <FileImage className="w-4 h-4 mr-2" />
                  Export Full Chat (PDF)
                  {billingData?.user?.planType === 'free' && (
                    <span className="ml-2 text-xs text-orange-600 dark:text-orange-400">Upgrade Tier</span>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      )}

      {/* Chat Input */}
      <div className="p-4 border-t border-slate-200 dark:border-slate-700">
        <div className="flex items-center space-x-2">
          <Input
            type="text"
            placeholder="Ask about your data..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1 text-sm focus:ring-2 focus:ring-primary focus:border-transparent"
            disabled={chatMutation.isPending}
          />
          <Button
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || chatMutation.isPending}
            className="bg-primary text-white hover:bg-primary/90"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}
