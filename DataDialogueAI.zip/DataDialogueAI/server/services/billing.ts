import { db } from "../db";
import { users, tokenUsage, billingEvents, PRICING_PLANS, USAGE_LIMITS, TOKEN_COSTS, type PlanType, type InsertTokenUsage, type InsertBillingEvent } from "@shared/schema";
import { eq, and, gte, sum, desc } from "drizzle-orm";

export class BillingService {
  
  async checkTokenLimit(userId: string, action: keyof typeof TOKEN_COSTS): Promise<{ allowed: boolean; reason?: string; upgradeRequired?: boolean }> {
    const user = await this.getUserBilling(userId);
    if (!user) {
      return { allowed: false, reason: "User not found" };
    }

    const tokensRequired = TOKEN_COSTS[action];
    
    // Check daily limit first
    if (user.dailyTokensUsed + tokensRequired > USAGE_LIMITS.dailyTokenLimit) {
      return { allowed: false, reason: "Daily token limit exceeded" };
    }

    const plan = PRICING_PLANS[user.planType as PlanType];
    
    // Reset monthly tokens if needed
    await this.resetMonthlyTokensIfNeeded(userId);
    
    // Get updated user data after potential reset
    const updatedUser = await this.getUserBilling(userId);
    if (!updatedUser) {
      return { allowed: false, reason: "User not found" };
    }

    const totalTokensNeeded = updatedUser.tokensUsed + tokensRequired;

    switch (user.planType) {
      case 'free':
        if (totalTokensNeeded > plan.tokens) {
          return { 
            allowed: false, 
            reason: "Free tier limit exceeded", 
            upgradeRequired: true 
          };
        }
        break;
        
      case 'flat':
        if (totalTokensNeeded > plan.tokens) {
          // Allow overage for flat plan
          return { 
            allowed: true, 
            reason: `Overage will be charged at $${plan.overageRate}/token` 
          };
        }
        break;
        
      case 'payg':
        // Always allowed, will be charged per token
        return { 
          allowed: true, 
          reason: `Will be charged $${plan.overageRate}/token` 
        };
        
      case 'enterprise':
        if (totalTokensNeeded > plan.tokens) {
          return { 
            allowed: true, 
            reason: `Enterprise overage at $${plan.overageRate}/token` 
          };
        }
        break;
    }

    return { allowed: true };
  }

  async consumeTokens(userId: string, action: keyof typeof TOKEN_COSTS): Promise<{ success: boolean; cost?: number; error?: string }> {
    const user = await this.getUserBilling(userId);
    if (!user) {
      return { success: false, error: "User not found" };
    }

    const tokensRequired = TOKEN_COSTS[action];
    const plan = PRICING_PLANS[user.planType as PlanType];
    
    let cost = 0;
    let isOverage = false;

    // Calculate cost
    switch (user.planType) {
      case 'free':
        cost = 0; // No charge for free tier
        break;
        
      case 'flat':
        const remaining = Math.max(0, plan.tokens - user.tokensUsed);
        if (tokensRequired > remaining) {
          const overageTokens = tokensRequired - remaining;
          cost = overageTokens * plan.overageRate;
          isOverage = true;
        }
        break;
        
      case 'payg':
        cost = tokensRequired * plan.overageRate;
        break;
        
      case 'enterprise':
        const enterpriseRemaining = Math.max(0, plan.tokens - user.tokensUsed);
        if (tokensRequired > enterpriseRemaining) {
          const overageTokens = tokensRequired - enterpriseRemaining;
          cost = overageTokens * plan.overageRate;
          isOverage = true;
        }
        break;
    }

    try {
      await db.transaction(async (tx) => {
        // Update user token usage
        await tx
          .update(users)
          .set({
            tokensUsed: user.tokensUsed + tokensRequired,
            dailyTokensUsed: user.dailyTokensUsed + tokensRequired,
            ...(isOverage && { overageTokens: user.overageTokens + (tokensRequired - Math.max(0, plan.tokens - user.tokensUsed)) })
          })
          .where(eq(users.id, userId));

        // Record token usage
        const tokenUsageRecord: InsertTokenUsage = {
          userId,
          action,
          tokensConsumed: tokensRequired,
          cost: cost.toString(),
        };
        await tx.insert(tokenUsage).values(tokenUsageRecord);

        // Record billing event if there's a cost
        if (cost > 0) {
          const billingEvent: InsertBillingEvent = {
            userId,
            eventType: user.planType === 'payg' ? 'payg' : 'overage',
            amount: cost.toString(),
            tokensCharged: tokensRequired,
            status: 'pending',
          };
          await tx.insert(billingEvents).values(billingEvent);
        }
      });

      return { success: true, cost };
    } catch (error) {
      console.error('Error consuming tokens:', error);
      return { success: false, error: 'Failed to consume tokens' };
    }
  }

  async getUserBilling(userId: string) {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, userId));
    return user;
  }

  async resetMonthlyTokensIfNeeded(userId: string): Promise<boolean> {
    const user = await this.getUserBilling(userId);
    if (!user) return false;

    const now = new Date();
    const lastReset = new Date(user.lastResetDate);
    
    // Check if it's a new month
    if (now.getMonth() !== lastReset.getMonth() || now.getFullYear() !== lastReset.getFullYear()) {
      await db
        .update(users)
        .set({
          tokensUsed: 0,
          overageTokens: 0,
          lastResetDate: now,
        })
        .where(eq(users.id, userId));
      return true;
    }

    return false;
  }

  async resetDailyTokensIfNeeded(userId: string): Promise<boolean> {
    const user = await this.getUserBilling(userId);
    if (!user) return false;

    const now = new Date();
    const lastReset = new Date(user.lastDailyReset);
    
    // Check if it's a new day
    if (now.toDateString() !== lastReset.toDateString()) {
      await db
        .update(users)
        .set({
          dailyTokensUsed: 0,
          lastDailyReset: now,
        })
        .where(eq(users.id, userId));
      return true;
    }

    return false;
  }

  async getUserUsageStats(userId: string) {
    const user = await this.getUserBilling(userId);
    if (!user) return null;

    const plan = PRICING_PLANS[user.planType as PlanType];
    
    // Get monthly usage breakdown
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    
    const monthlyUsage = await db
      .select({
        action: tokenUsage.action,
        totalTokens: sum(tokenUsage.tokensConsumed),
        totalCost: sum(tokenUsage.cost),
      })
      .from(tokenUsage)
      .where(
        and(
          eq(tokenUsage.userId, userId),
          gte(tokenUsage.timestamp, monthStart)
        )
      )
      .groupBy(tokenUsage.action);

    // Get recent billing events
    const recentBilling = await db
      .select()
      .from(billingEvents)
      .where(eq(billingEvents.userId, userId))
      .orderBy(desc(billingEvents.timestamp))
      .limit(10);

    return {
      user: {
        planType: user.planType,
        tokensUsed: user.tokensUsed,
        tokensRemaining: Math.max(0, plan.tokens - user.tokensUsed),
        monthlyLimit: plan.tokens,
        dailyUsed: user.dailyTokensUsed,
        dailyLimit: USAGE_LIMITS.dailyTokenLimit,
        overageTokens: user.overageTokens,
      },
      plan,
      monthlyUsage,
      recentBilling,
    };
  }

  async upgradePlan(userId: string, newPlan: PlanType): Promise<{ success: boolean; error?: string }> {
    try {
      const plan = PRICING_PLANS[newPlan];
      
      await db
        .update(users)
        .set({
          planType: newPlan,
          monthlyTokenCap: plan.tokens,
          isEnterprise: newPlan === 'enterprise',
        })
        .where(eq(users.id, userId));

      return { success: true };
    } catch (error) {
      console.error('Error upgrading plan:', error);
      return { success: false, error: 'Failed to upgrade plan' };
    }
  }

  async checkAbusePattern(userId: string): Promise<{ flagged: boolean; reason?: string }> {
    const user = await this.getUserBilling(userId);
    if (!user) return { flagged: false };

    // Check if flat plan user exceeds abuse threshold
    if (user.planType === 'flat' && user.tokensUsed > USAGE_LIMITS.abuseThreshold) {
      return { 
        flagged: true, 
        reason: `Flat plan user exceeded ${USAGE_LIMITS.abuseThreshold} tokens/month` 
      };
    }

    // Check daily usage patterns
    if (user.dailyTokensUsed > USAGE_LIMITS.dailyTokenLimit) {
      return { 
        flagged: true, 
        reason: 'Daily token limit exceeded' 
      };
    }

    return { flagged: false };
  }
}

export const billingService = new BillingService();