import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/theme-toggle";
import { DemoVideoModal } from "@/components/demo-video-modal";
import { 
  ChartLine, 
  Upload, 
  MessageSquare, 
  BarChart3, 
  Brain, 
  Shield, 
  Zap, 
  Users,
  CheckCircle,
  ArrowRight
} from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: Upload,
      title: "Smart Data Import",
      description: "Upload CSV, Excel, JSON, XML files with automatic type detection and validation"
    },
    {
      icon: Brain,
      title: "AI-Powered Analysis",
      description: "Ask questions in natural language and get intelligent insights from your data"
    },
    {
      icon: BarChart3,
      title: "Interactive Visualizations",
      description: "Generate beautiful charts and graphs with AI-recommended visualization types"
    },
    {
      icon: MessageSquare,
      title: "Conversational Interface",
      description: "Chat with your data using advanced AI to uncover hidden patterns and trends"
    },
    {
      icon: Users,
      title: "Team Collaboration",
      description: "Share reports and insights with your team for better decision making"
    },
    {
      icon: Shield,
      title: "Secure & Private",
      description: "Enterprise-grade security with encrypted data storage and processing"
    }
  ];

  const pricingPlans = [
    {
      name: "Free",
      price: "$0",
      period: "/month",
      tokens: "20 tokens",
      features: ["Basic data upload", "AI chat analysis", "Simple visualizations", "Export reports"],
      highlight: false
    },
    {
      name: "Professional",
      price: "$20",
      period: "/month", 
      tokens: "150 tokens",
      features: ["Advanced analytics", "Custom visualizations", "Team sharing", "Priority support"],
      highlight: true
    },
    {
      name: "Enterprise",
      price: "$180",
      period: "/month",
      tokens: "1,500 tokens",
      features: ["Unlimited features", "Advanced security", "Custom integrations", "Dedicated support"],
      highlight: false
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                <ChartLine className="text-white w-6 h-6" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">DataDialogue AI</h1>
                <p className="text-sm text-slate-600 dark:text-slate-400">Intelligent Analytics Platform</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <ThemeToggle />
              <Button asChild>
                <a href="/api/login" className="flex items-center gap-2">
                  Sign In
                  <ArrowRight className="w-4 h-4" />
                </a>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-6">
        <div className="container mx-auto text-center">

          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 dark:text-slate-100 mb-6">
            Transform Data into
            <span className="text-primary block">Intelligent Insights</span>
          </h1>
          <p className="text-xl text-slate-600 dark:text-slate-400 mb-8 max-w-3xl mx-auto">
            Upload your data, ask questions in natural language, and get AI-powered analytics 
            with interactive visualizations. No coding required.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild className="text-lg px-8 py-4">
              <a href="/api/login" className="flex items-center gap-2">
                Get Started Free
                <ArrowRight className="w-5 h-5" />
              </a>
            </Button>
            <DemoVideoModal>
              <Button size="lg" variant="outline" className="text-lg px-8 py-4">
                View Demo
              </Button>
            </DemoVideoModal>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 bg-white dark:bg-slate-900">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-900 dark:text-slate-100 mb-4">
              Powerful Features for Data Analysis
            </h2>
            <p className="text-xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              Everything you need to turn raw data into actionable insights
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 px-6">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-900 dark:text-slate-100 mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              Choose the plan that fits your needs. All plans include core features.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {pricingPlans.map((plan, index) => (
              <Card key={index} className={`relative ${plan.highlight ? 'ring-2 ring-primary shadow-lg scale-105' : ''}`}>
                {plan.highlight && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    Most Popular
                  </Badge>
                )}
                <CardHeader className="text-center pb-8">
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <div className="mt-4">
                    <span className="text-4xl font-bold text-slate-900 dark:text-slate-100">
                      {plan.price}
                    </span>
                    <span className="text-slate-600 dark:text-slate-400">{plan.period}</span>
                  </div>
                  <Badge variant="outline" className="mt-2">
                    {plan.tokens}
                  </Badge>
                </CardHeader>
                <CardContent className="space-y-4">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      <span className="text-slate-700 dark:text-slate-300">{feature}</span>
                    </div>
                  ))}
                  <Button 
                    className="w-full mt-6" 
                    variant={plan.highlight ? "default" : "outline"}
                    asChild
                  >
                    <a href="/api/login">
                      {plan.name === "Free" ? "Get Started" : "Choose Plan"}
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-primary text-white">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Transform Your Data?</h2>
          <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto">
            Join individuals and teams using DataDialogue AI to make data-driven decisions faster.
          </p>
          <Button size="lg" variant="secondary" asChild className="text-lg px-8 py-4">
            <a href="/api/login" className="flex items-center gap-2">
              Start Your Free Trial
              <ArrowRight className="w-5 h-5" />
            </a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-700 py-12 px-6">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <ChartLine className="text-white w-5 h-5" />
            </div>
            <span className="text-xl font-bold text-slate-900 dark:text-slate-100">DataDialogue AI</span>
          </div>
          <p className="text-slate-600 dark:text-slate-400">
            © 2025 DataDialogue AI. Transform your data into intelligent insights.
          </p>
        </div>
      </footer>
    </div>
  );
}