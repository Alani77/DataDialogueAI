import { useQuery } from "@tanstack/react-query";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Zap, TrendingUp, AlertTriangle, Crown } from "lucide-react";
import { PRICING_PLANS } from "@shared/schema";

interface UsageStats {
  user: {
    planType: string;
    tokensUsed: number;
    tokensRemaining: number;
    monthlyLimit: number;
    dailyUsed: number;
    dailyLimit: number;
    overageTokens: number;
    pendingCharges?: number;
  };
  plan: typeof PRICING_PLANS[keyof typeof PRICING_PLANS];
  monthlyUsage: Array<{
    action: string;
    totalTokens: number;
    totalCost: number;
  }>;
}

export function TokenMeter() {
  const { data: usage, isLoading } = useQuery<UsageStats>({
    queryKey: ['/api/billing/usage'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (isLoading || !usage) {
    return (
      <Card className="w-full">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Zap className="w-4 h-4" />
            Token Usage
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded animate-pulse" />
            <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded animate-pulse w-2/3" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const { user, plan } = usage;
  const usagePercentage = user.monthlyLimit > 0 ? (user.tokensUsed / user.monthlyLimit) * 100 : 0;
  const dailyPercentage = (user.dailyUsed / user.dailyLimit) * 100;
  const isNearLimit = usagePercentage > 80;
  const isOverLimit = user.tokensUsed > user.monthlyLimit;

  const getPlanBadgeVariant = (planType: string) => {
    switch (planType) {
      case 'enterprise': return 'default';
      case 'flat': return 'secondary';
      case 'payg': return 'outline';
      default: return 'outline';
    }
  };

  const getPlanIcon = (planType: string) => {
    switch (planType) {
      case 'enterprise': return <Crown className="w-3 h-3" />;
      case 'flat': return <TrendingUp className="w-3 h-3" />;
      default: return <Zap className="w-3 h-3" />;
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4" />
            Token Usage
          </div>
          <Badge variant={getPlanBadgeVariant(user.planType)} className="text-xs">
            {getPlanIcon(user.planType)}
            {plan.name}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Monthly Usage */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-slate-600 dark:text-slate-400">Monthly</span>
            <span className="font-medium">
              {user.tokensUsed} / {user.monthlyLimit || '∞'} tokens
            </span>
          </div>
          {user.monthlyLimit > 0 && (
            <Progress 
              value={Math.min(usagePercentage, 100)} 
              className={`h-2 ${isNearLimit ? 'bg-orange-100 dark:bg-orange-900' : ''}`}
            />
          )}
          {isOverLimit && user.overageTokens > 0 && (
            <div className="flex items-center gap-1 text-xs text-orange-600 dark:text-orange-400">
              <AlertTriangle className="w-3 h-3" />
              {user.overageTokens} overage tokens (${(user.overageTokens * plan.overageRate).toFixed(2)})
            </div>
          )}
        </div>

        {/* Daily Usage */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-slate-600 dark:text-slate-400">Today</span>
            <span className="font-medium">
              {user.dailyUsed} / {user.dailyLimit} tokens
            </span>
          </div>
          <Progress 
            value={Math.min(dailyPercentage, 100)} 
            className={`h-1 ${dailyPercentage > 80 ? 'bg-red-100 dark:bg-red-900' : ''}`}
          />
        </div>

        {/* Pay-As-You-Go Pending Charges */}
        {user.planType === 'payg' && user.pendingCharges !== undefined && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-slate-600 dark:text-slate-400">Pending Bill</span>
              <span className="font-medium text-blue-600 dark:text-blue-400">
                ${user.pendingCharges.toFixed(2)}
              </span>
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400">
              Billed monthly on the 1st
            </div>
          </div>
        )}

        {/* Usage Breakdown */}
        {usage.monthlyUsage && usage.monthlyUsage.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-xs font-medium text-slate-700 dark:text-slate-300">This Month</h4>
            <div className="space-y-1">
              {usage.monthlyUsage.map((item, index) => (
                <div key={index} className="flex justify-between text-xs">
                  <span className="capitalize text-slate-600 dark:text-slate-400">
                    {item.action}
                  </span>
                  <span className="font-medium">
                    {item.totalTokens} tokens
                    {item.totalCost > 0 && (
                      <span className="text-slate-500 ml-1">
                        (${parseFloat(item.totalCost.toString()).toFixed(2)})
                      </span>
                    )}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Upgrade Prompt */}
        {(user.planType === 'free' && usagePercentage > 60) && (
          <div className="p-3 bg-primary/10 rounded-lg">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <div className="space-y-2">
                <p className="text-xs text-primary font-medium">
                  You're using {Math.round(usagePercentage)}% of your free tokens
                </p>
                <Button 
                  size="sm" 
                  className="h-6 text-xs"
                  onClick={() => {
                    // Trigger upgrade modal - we'll need to pass this down from the parent
                    window.dispatchEvent(new CustomEvent('showUpgradeModal'));
                  }}
                >
                  Upgrade Plan
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Plan Details */}
        <div className="pt-2 border-t border-slate-200 dark:border-slate-700">
          <div className="flex justify-between text-xs text-slate-600 dark:text-slate-400">
            <span>Plan: ${plan.price}/month</span>
            {plan.overage && (
              <span>Overage: ${plan.overageRate}/token</span>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}