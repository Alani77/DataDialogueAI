import Papa from 'papaparse';

export interface ParsedData {
  data: any[];
  columns: string[];
  errors: string[];
}

export function parseCSV(file: File): Promise<ParsedData> {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (header) => header.trim(),
      transform: (value) => {
        // Try to parse numbers
        if (!isNaN(Number(value)) && value.trim() !== '') {
          return Number(value);
        }
        // Try to parse dates
        if (Date.parse(value)) {
          return new Date(value);
        }
        return value;
      },
      complete: (result) => {
        if (result.errors.length > 0) {
          resolve({
            data: result.data as any[],
            columns: result.meta.fields || [],
            errors: result.errors.map(err => err.message)
          });
        } else {
          resolve({
            data: result.data as any[],
            columns: result.meta.fields || [],
            errors: []
          });
        }
      },
      error: (error) => {
        reject(new Error(`CSV parsing error: ${error.message}`));
      }
    });
  });
}

export function parseTSV(file: File): Promise<ParsedData> {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      delimiter: '\t',
      skipEmptyLines: true,
      transformHeader: (header) => header.trim(),
      transform: (value) => {
        if (!isNaN(Number(value)) && value.trim() !== '') {
          return Number(value);
        }
        if (Date.parse(value)) {
          return new Date(value);
        }
        return value;
      },
      complete: (result) => {
        resolve({
          data: result.data as any[],
          columns: result.meta.fields || [],
          errors: result.errors.map(err => err.message)
        });
      },
      error: (error) => {
        reject(new Error(`TSV parsing error: ${error.message}`));
      }
    });
  });
}

export async function parseJSON(file: File): Promise<ParsedData> {
  try {
    const text = await file.text();
    let data = JSON.parse(text);
    
    // Handle different JSON structures
    if (!Array.isArray(data)) {
      if (typeof data === 'object' && data !== null) {
        // If it's an object, try to find an array property
        const arrayKey = Object.keys(data).find(key => Array.isArray(data[key]));
        if (arrayKey) {
          data = data[arrayKey];
        } else {
          // Convert single object to array
          data = [data];
        }
      } else {
        throw new Error('JSON must contain an array or object with array property');
      }
    }

    const columns = data.length > 0 ? Object.keys(data[0]) : [];
    
    return {
      data,
      columns,
      errors: []
    };
  } catch (error) {
    throw new Error(`JSON parsing error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function parseXML(file: File): Promise<ParsedData> {
  try {
    const text = await file.text();
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(text, 'text/xml');
    
    if (xmlDoc.getElementsByTagName('parsererror').length > 0) {
      throw new Error('Invalid XML format');
    }

    // Convert XML to JSON-like structure
    const data = xmlToJson(xmlDoc.documentElement);
    let arrayData: any[] = [];

    // Try to find array-like structures in the XML
    if (Array.isArray(data)) {
      arrayData = data;
    } else if (typeof data === 'object' && data !== null) {
      // Look for repeated elements that could represent rows
      const keys = Object.keys(data);
      for (const key of keys) {
        if (Array.isArray(data[key])) {
          arrayData = data[key];
          break;
        }
      }
      if (arrayData.length === 0) {
        arrayData = [data];
      }
    }

    const columns = arrayData.length > 0 ? Object.keys(arrayData[0]) : [];

    return {
      data: arrayData,
      columns,
      errors: []
    };
  } catch (error) {
    throw new Error(`XML parsing error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

function xmlToJson(xml: Element): any {
  const obj: any = {};
  
  if (xml.hasAttributes()) {
    for (let i = 0; i < xml.attributes.length; i++) {
      const attribute = xml.attributes[i];
      obj[`@${attribute.nodeName}`] = attribute.nodeValue;
    }
  }

  if (xml.hasChildNodes()) {
    for (let i = 0; i < xml.childNodes.length; i++) {
      const item = xml.childNodes[i];
      const nodeName = item.nodeName;
      
      if (item.nodeType === 1) { // Element node
        if (typeof obj[nodeName] === 'undefined') {
          obj[nodeName] = xmlToJson(item as Element);
        } else {
          if (!Array.isArray(obj[nodeName])) {
            obj[nodeName] = [obj[nodeName]];
          }
          obj[nodeName].push(xmlToJson(item as Element));
        }
      } else if (item.nodeType === 3 && item.nodeValue?.trim()) { // Text node
        return item.nodeValue.trim();
      }
    }
  }
  
  return obj;
}
