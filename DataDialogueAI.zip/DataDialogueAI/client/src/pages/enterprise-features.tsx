import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TeamDashboard } from "@/components/team-dashboard";
import { WhiteLabelSettings } from "@/components/white-label-settings";
import { PrioritySupport } from "@/components/priority-support";
import { Crown, Users, Palette, Headphones, Settings, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function EnterpriseFeatures() {
  const [activeTab, setActiveTab] = useState("dashboard");

  // Check if user has enterprise plan
  const { data: userStats, isLoading } = useQuery<{user: {planType: string}}>({
    queryKey: ['/api/billing/usage'],
  });

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  // Redirect if not enterprise user
  if (userStats?.user?.planType !== 'enterprise') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-6">
        <div className="max-w-2xl mx-auto">
          <div className="text-center">
            <Crown className="w-16 h-16 mx-auto text-amber-500 mb-6" />
            <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-4">
              Enterprise Features
            </h1>
            <p className="text-slate-600 dark:text-slate-400 mb-8">
              These premium features are available exclusively to Enterprise plan subscribers.
            </p>
            
            <Card className="border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/20 mb-8">
              <CardContent className="p-6">
                <div className="text-amber-800 dark:text-amber-200">
                  <h3 className="font-semibold mb-3">Enterprise Features Include:</h3>
                  <ul className="text-sm space-y-2">
                    <li>• Team dashboard with real-time analytics</li>
                    <li>• Priority support with dedicated account manager</li>
                    <li>• White-label options for custom branding</li>
                    <li>• Custom integrations and API access</li>
                    <li>• 1,500 tokens per month with low overage rates</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <div className="flex gap-4 justify-center">
              <Link href="/dashboard">
                <Button variant="outline">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <Button className="bg-amber-600 hover:bg-amber-700 text-white">
                <Crown className="w-4 h-4 mr-2" />
                Upgrade to Enterprise
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <div className="bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="outline" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Crown className="w-6 h-6 text-amber-500" />
                Enterprise Features
              </h1>
              <p className="text-slate-600 dark:text-slate-400">
                Advanced tools and analytics for your organization
              </p>
            </div>
          </div>
          <Badge variant="secondary" className="bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200">
            Enterprise Plan Active
          </Badge>
        </div>
      </div>

      <div className="p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-4">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">Team Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="branding" className="flex items-center gap-2">
              <Palette className="w-4 h-4" />
              <span className="hidden sm:inline">White Label</span>
            </TabsTrigger>
            <TabsTrigger value="support" className="flex items-center gap-2">
              <Headphones className="w-4 h-4" />
              <span className="hidden sm:inline">Priority Support</span>
            </TabsTrigger>
            <TabsTrigger value="integrations" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              <span className="hidden sm:inline">Integrations</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="mt-6">
            <TeamDashboard />
          </TabsContent>

          <TabsContent value="branding" className="mt-6">
            <WhiteLabelSettings />
          </TabsContent>

          <TabsContent value="support" className="mt-6">
            <PrioritySupport />
          </TabsContent>

          <TabsContent value="integrations" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Custom Integrations
                  <Badge variant="secondary" className="text-xs">Enterprise Only</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="border-dashed">
                      <CardContent className="p-6 text-center">
                        <Settings className="w-12 h-12 mx-auto text-slate-400 mb-4" />
                        <h3 className="font-semibold mb-2">REST API Access</h3>
                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                          Full API access for custom integrations and automation
                        </p>
                        <Button variant="outline">Configure API</Button>
                      </CardContent>
                    </Card>

                    <Card className="border-dashed">
                      <CardContent className="p-6 text-center">
                        <Settings className="w-12 h-12 mx-auto text-slate-400 mb-4" />
                        <h3 className="font-semibold mb-2">Webhook Integration</h3>
                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                          Real-time data sync with your existing systems
                        </p>
                        <Button variant="outline">Setup Webhooks</Button>
                      </CardContent>
                    </Card>

                    <Card className="border-dashed">
                      <CardContent className="p-6 text-center">
                        <Settings className="w-12 h-12 mx-auto text-slate-400 mb-4" />
                        <h3 className="font-semibold mb-2">SSO Integration</h3>
                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                          Single sign-on with your identity provider
                        </p>
                        <Button variant="outline">Configure SSO</Button>
                      </CardContent>
                    </Card>

                    <Card className="border-dashed">
                      <CardContent className="p-6 text-center">
                        <Settings className="w-12 h-12 mx-auto text-slate-400 mb-4" />
                        <h3 className="font-semibold mb-2">Custom Connectors</h3>
                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                          Connect to proprietary data sources and tools
                        </p>
                        <Button variant="outline">Request Integration</Button>
                      </CardContent>
                    </Card>
                  </div>

                  <Card className="border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/20">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Crown className="w-5 h-5 text-amber-600 mt-0.5" />
                        <div className="text-amber-800 dark:text-amber-200">
                          <h4 className="font-semibold mb-1">Need a Custom Integration?</h4>
                          <p className="text-sm">
                            Our enterprise team can build custom integrations for your specific needs. 
                            Contact your account manager to discuss requirements.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}