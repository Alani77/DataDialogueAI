import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Coins } from "lucide-react";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface TokenPurchaseFormProps {
  tokens: number;
  amount: number;
  onSuccess: () => void;
}

const TokenPurchaseForm = ({ tokens, amount, onSuccess }: TokenPurchaseFormProps) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements || isProcessing) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/dashboard?payment=success&tokens=${tokens}`,
        },
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Payment Successful",
          description: `Successfully purchased ${tokens} tokens!`,
        });
        onSuccess();
      }
    } catch (error) {
      toast({
        title: "Payment Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="text-center p-4 bg-muted rounded-lg">
        <Coins className="h-8 w-8 mx-auto mb-2 text-primary" />
        <p className="text-lg font-semibold">{tokens} Tokens</p>
        <p className="text-sm text-muted-foreground">${amount.toFixed(2)} total</p>
      </div>
      
      <PaymentElement />
      
      <Button 
        type="submit" 
        disabled={!stripe || isProcessing}
        className="w-full"
      >
        {isProcessing ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Processing...
          </>
        ) : (
          `Purchase for $${amount.toFixed(2)}`
        )}
      </Button>
    </form>
  );
};

export default function TokenPurchase() {
  const [clientSecret, setClientSecret] = useState("");
  const [loading, setLoading] = useState(false);
  const [tokens, setTokens] = useState(50);
  const [amount, setAmount] = useState(1.0);
  const { toast } = useToast();

  // Pay-as-you-go rate: $0.02 per token
  const tokenRate = 0.02;

  useEffect(() => {
    setAmount(tokens * tokenRate);
  }, [tokens]);

  const createPaymentIntent = async () => {
    if (tokens < 1 || amount < 0.5) {
      toast({
        title: "Invalid Amount",
        description: "Minimum purchase is 25 tokens ($0.50)",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    
    try {
      const response = await apiRequest("POST", "/api/stripe/create-payment-intent", { 
        amount,
        tokens,
        email: `user@datadialogue.ai`
      });
      
      const data = await response.json();
      
      if (data.clientSecret) {
        setClientSecret(data.clientSecret);
      } else {
        throw new Error(data.error || 'Failed to create payment intent');
      }
    } catch (error) {
      console.error('Payment intent creation error:', error);
      toast({
        title: "Setup Error",
        description: "Failed to set up payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSuccess = () => {
    // Redirect to dashboard after successful payment
    window.location.href = `/dashboard?payment=success&tokens=${tokens}`;
  };

  const presetAmounts = [
    { tokens: 25, amount: 0.50 },
    { tokens: 50, amount: 1.00 },
    { tokens: 100, amount: 2.00 },
    { tokens: 250, amount: 5.00 },
    { tokens: 500, amount: 10.00 },
  ];

  if (clientSecret) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle>Purchase Tokens</CardTitle>
            <CardDescription>
              Pay-as-you-go token purchase
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Elements 
              stripe={stripePromise} 
              options={{ 
                clientSecret,
                appearance: {
                  theme: 'stripe',
                  variables: {
                    colorPrimary: 'hsl(var(--primary))',
                  }
                }
              }}
            >
              <TokenPurchaseForm 
                tokens={tokens}
                amount={amount}
                onSuccess={handleSuccess}
              />
            </Elements>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle>Purchase Tokens</CardTitle>
          <CardDescription>
            Buy tokens for pay-as-you-go usage at $0.02 per token
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Preset amounts */}
          <div>
            <Label className="text-sm font-medium">Quick Select</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {presetAmounts.map((preset) => (
                <Button
                  key={preset.tokens}
                  variant={tokens === preset.tokens ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTokens(preset.tokens)}
                  className="text-xs"
                >
                  {preset.tokens} tokens
                  <br />
                  ${preset.amount.toFixed(2)}
                </Button>
              ))}
            </div>
          </div>

          {/* Custom amount */}
          <div className="space-y-2">
            <Label htmlFor="tokens">Custom Amount (tokens)</Label>
            <Input
              id="tokens"
              type="number"
              min="1"
              max="1000"
              value={tokens}
              onChange={(e) => setTokens(Math.max(1, parseInt(e.target.value) || 1))}
              placeholder="Enter token amount"
            />
            <p className="text-sm text-muted-foreground">
              Total: ${amount.toFixed(2)} ({tokens} × $0.02)
            </p>
          </div>

          <Button 
            onClick={createPaymentIntent}
            disabled={loading || tokens < 1}
            className="w-full"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Setting up...
              </>
            ) : (
              `Continue to Payment`
            )}
          </Button>

          <div className="text-center">
            <Button variant="link" onClick={() => window.history.back()}>
              ← Back to Dashboard
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}