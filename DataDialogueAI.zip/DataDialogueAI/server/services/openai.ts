import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface AnalysisRequest {
  query: string;
  data: any[];
  columns: string[];
  context?: string;
}

export interface AnalysisResponse {
  insights: string;
  summary: string;
  recommendations: string[];
  visualizations: VisualizationSpec[];
  followUpQuestions: string[];
}

export interface VisualizationSpec {
  type: 'line' | 'bar' | 'scatter' | 'pie' | 'heatmap';
  title: string;
  data: any;
  layout: any;
  description: string;
}

export async function analyzeDataWithAI(request: AnalysisRequest): Promise<AnalysisResponse> {
  try {
    const prompt = `You are an expert data analyst. Analyze the following data and respond with insights, visualizations, and recommendations.

Query: ${request.query}
Data Structure: ${JSON.stringify(request.columns)}
Sample Data (first 10 rows): ${JSON.stringify(request.data.slice(0, 10))}
Total Rows: ${request.data.length}
${request.context ? `Context: ${request.context}` : ''}

Please provide a comprehensive analysis in the following JSON format:
{
  "insights": "Key findings and patterns in the data",
  "summary": "Brief overview of the analysis",
  "recommendations": ["actionable recommendation 1", "recommendation 2"],
  "visualizations": [
    {
      "type": "line|bar|scatter|pie|heatmap",
      "title": "Chart title",
      "data": "Plotly.js compatible data array",
      "layout": "Plotly.js compatible layout object",
      "description": "What this visualization shows"
    }
  ],
  "followUpQuestions": ["relevant follow-up question 1", "question 2"]
}

Focus on providing actionable insights and appropriate visualizations based on the data type and user query.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert data analyst specializing in business intelligence and data visualization. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 2000
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      insights: result.insights || "No specific insights found.",
      summary: result.summary || "Analysis completed.",
      recommendations: result.recommendations || [],
      visualizations: result.visualizations || [],
      followUpQuestions: result.followUpQuestions || []
    };
  } catch (error) {
    console.error("OpenAI analysis error:", error);
    throw new Error(`Failed to analyze data: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function generateVisualization(data: any[], columns: string[], chartType: string, title: string): Promise<VisualizationSpec> {
  try {
    const prompt = `Create a ${chartType} visualization for the following data:

Columns: ${JSON.stringify(columns)}
Sample Data: ${JSON.stringify(data.slice(0, 20))}
Chart Type: ${chartType}
Title: ${title}

Return a JSON object with Plotly.js compatible configuration:
{
  "type": "${chartType}",
  "title": "${title}",
  "data": [Plotly.js data traces],
  "layout": {Plotly.js layout configuration},
  "description": "Brief description of what this chart shows"
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a data visualization expert. Create Plotly.js compatible chart configurations. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3
    });

    return JSON.parse(response.choices[0].message.content || '{}');
  } catch (error) {
    console.error("Visualization generation error:", error);
    throw new Error(`Failed to generate visualization: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}
