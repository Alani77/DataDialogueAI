import { sql } from "drizzle-orm";
import { pgTable, text, varchar, json, timestamp, integer, decimal, boolean, index, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  planType: varchar("plan_type", { length: 20 }).notNull().default("free"),
  monthlyTokenCap: integer("monthly_token_cap").notNull().default(20),
  tokensUsed: integer("tokens_used").notNull().default(0),
  overageTokens: integer("overage_tokens").notNull().default(0),
  lastResetDate: timestamp("last_reset_date").defaultNow().notNull(),
  stripeCustomerId: varchar("stripe_customer_id", { length: 255 }),
  stripeSubscriptionId: varchar("stripe_subscription_id", { length: 255 }),
  dailyTokensUsed: integer("daily_tokens_used").notNull().default(0),
  lastDailyReset: timestamp("last_daily_reset").defaultNow().notNull(),
  isEnterprise: boolean("is_enterprise").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const tokenUsage = pgTable("token_usage", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  action: varchar("action", { length: 50 }).notNull(), // upload, query, visualization
  tokensConsumed: integer("tokens_consumed").notNull(),
  cost: decimal("cost", { precision: 10, scale: 4 }),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const billingEvents = pgTable("billing_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  eventType: varchar("event_type", { length: 50 }).notNull(), // subscription, overage, payg
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  tokensCharged: integer("tokens_charged"),
  stripePaymentIntentId: varchar("stripe_payment_intent_id", { length: 255 }),
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const datasets = pgTable("datasets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  filename: text("filename").notNull(),
  fileType: text("file_type").notNull(),
  data: json("data").notNull(),
  columns: json("columns").notNull(),
  rowCount: integer("row_count").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

export const conversations = pgTable("conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  datasetId: varchar("dataset_id").notNull().references(() => datasets.id),
  userId: varchar("user_id").notNull(),
  messages: jsonb("messages").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insights = pgTable("insights", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  datasetId: varchar("dataset_id").notNull().references(() => datasets.id),
  userId: varchar("user_id").notNull(),
  query: text("query").notNull(),
  response: jsonb("response").notNull(),
  visualizations: jsonb("visualizations"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Pricing constants
export const PRICING_PLANS = {
  free: {
    name: "Free Tier",
    price: 0,
    tokens: 20, // Monthly free allocation
    overage: false,
    overageRate: 0,
  },
  flat: {
    name: "Flat Subscription",
    price: 20,
    tokens: 150, // Perfect for small-medium teams
    overage: true,
    overageRate: 0.012, // $0.012 per token
  },
  payg: {
    name: "Pay-As-You-Go",
    price: 0,
    tokens: 0, // No base allocation
    overage: true,
    overageRate: 0.02, // $0.02 per token
  },
  enterprise: {
    name: "Enterprise",
    price: 180,
    tokens: 1500, // High volume for large organizations
    overage: true,
    overageRate: 0.005, // $0.005 per token
  },
} as const;

export const USAGE_LIMITS = {
  dailyTokenLimit: {
    free: 10, // 10 tokens per day for free tier (increased from 5 for better user experience)
    flat: 20, // 20 tokens per day for flat tier (150/month = ~5 per day average)
    payg: 100, // 100 tokens per day for pay-as-you-go (unlimited monthly but reasonable daily cap)
    enterprise: 75, // 75 tokens per day for enterprise (1500/month = ~50 per day average)
  },
  maxFileSize: 50 * 1024 * 1024, // 50MB for larger datasets
  rateLimit: 30, // requests per minute
  abuseThreshold: 1000, // tokens per month for alerts
} as const;

export const TOKEN_COSTS = {
  upload: 1,
  query: 2,
  visualization: 1,
} as const;

export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const upsertUserSchema = createInsertSchema(users).pick({
  id: true,
  email: true,
  firstName: true,
  lastName: true,
  profileImageUrl: true,
});

export const insertTokenUsageSchema = createInsertSchema(tokenUsage).omit({
  id: true,
  timestamp: true,
});

export const insertBillingEventSchema = createInsertSchema(billingEvents).omit({
  id: true,
  timestamp: true,
});

export const insertDatasetSchema = createInsertSchema(datasets).omit({
  id: true,
  uploadedAt: true,
});

export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
});

export const insertInsightSchema = createInsertSchema(insights).omit({
  id: true,
  createdAt: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type TokenUsage = typeof tokenUsage.$inferSelect;
export type InsertTokenUsage = z.infer<typeof insertTokenUsageSchema>;
export type BillingEvent = typeof billingEvents.$inferSelect;
export type InsertBillingEvent = z.infer<typeof insertBillingEventSchema>;
export type Dataset = typeof datasets.$inferSelect;
export type InsertDataset = z.infer<typeof insertDatasetSchema>;
export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Insight = typeof insights.$inferSelect;
export type InsertInsight = z.infer<typeof insertInsightSchema>;

export type PlanType = keyof typeof PRICING_PLANS;

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  visualizations?: any[];
}

export interface DataColumn {
  name: string;
  type: 'string' | 'number' | 'date' | 'boolean';
  nullable: boolean;
}

export interface VisualizationData {
  type: 'line' | 'bar' | 'scatter' | 'pie' | 'heatmap';
  data: any[];
  layout: any;
  title: string;
}
