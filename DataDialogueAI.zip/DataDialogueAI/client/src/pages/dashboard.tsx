import { useState, useEffect } from "react";
import Sidebar from "@/components/sidebar";
import FileUpload from "@/components/file-upload";
import DataVisualization from "@/components/data-visualization";
import ChatInterface from "@/components/chat-interface";
import ExportModal from "@/components/export-modal";
import { UpgradeModal } from "@/components/upgrade-modal";


// Import view components
import UploadView from "@/components/views/upload-view";
import VisualizationsView from "@/components/views/visualizations-view";


import { ThemeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui/button";
import { Settings } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const [selectedDatasetId, setSelectedDatasetId] = useState<string | null>(null);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [activeView, setActiveView] = useState("dashboard");

  useEffect(() => {
    const handleShowUpgradeModal = () => setShowUpgradeModal(true);
    window.addEventListener('showUpgradeModal', handleShowUpgradeModal);
    return () => window.removeEventListener('showUpgradeModal', handleShowUpgradeModal);
  }, []);

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-900">
      <Sidebar 
        selectedDatasetId={selectedDatasetId}
        onDatasetSelect={setSelectedDatasetId}
        activeView={activeView}
        onViewChange={setActiveView}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">DataDialogue AI Workspace</h2>
              <p className="text-slate-600 dark:text-slate-400">Upload your data and start conversing with your data using AI</p>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/settings">
                <Button variant="outline" size="sm">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              </Link>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          <div className="p-6">
            {/* Render different views based on activeView */}
              {activeView === 'dashboard' && (
                <div className="flex flex-col space-y-6">
                  {/* Top Section - File Upload */}
                  <div className="w-full">
                    <FileUpload onDatasetUploaded={setSelectedDatasetId} />
                  </div>

                  {selectedDatasetId ? (
                    /* Main Content Area with Chat Prominence */
                    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                      {/* Left - Data Visualization */}
                      <div className="xl:col-span-2">
                        <DataVisualization datasetId={selectedDatasetId} />
                      </div>
                      
                      {/* Right - Chat Interface (Prominent Position) */}
                      <div className="xl:col-span-1">
                        <div className="sticky top-6">
                          <ChatInterface datasetId={selectedDatasetId} />
                        </div>
                      </div>
                    </div>
                  ) : (
                    /* Empty State */
                    <div className="bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 p-12 text-center">
                      <div className="max-w-md mx-auto">
                        <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2">
                          Ready to analyze your data?
                        </h3>
                        <p className="text-slate-600 dark:text-slate-400 mb-4">
                          Upload a dataset above or select one from the sidebar to start conversing with your data using AI
                        </p>
                        <div className="bg-slate-50 dark:bg-slate-700/50 rounded-lg p-4">
                          <p className="text-sm text-slate-500 dark:text-slate-400">
                            💡 Tip: Once you upload data, the AI chat will appear on the right for easy access
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

            {activeView === 'upload' && <UploadView />}
            {activeView === 'visualizations' && <VisualizationsView />}
          </div>
        </main>
      </div>

      <ExportModal 
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        datasetId={selectedDatasetId}
      />

      <UpgradeModal 
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        currentPlan="free"
      />


    </div>
  );
}
