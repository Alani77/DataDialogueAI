import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { BarChart3, PieChart, LineChart, TrendingUp, Eye, Download, Edit, Trash2, Share, X } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import Plot from "react-plotly.js";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

interface Visualization {
  id: string;
  title: string;
  type: string;
  datasetId: string;
  createdAt: string;
  visualization: any;
  conversationId: string;
  query: string;
}

export default function VisualizationsView() {
  const { data: visualizations = [], isLoading } = useQuery<Visualization[]>({
    queryKey: ["/api/visualizations"],
  });
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [newVisualizationOpen, setNewVisualizationOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [selectedVisualization, setSelectedVisualization] = useState<Visualization | null>(null);
  const [chartType, setChartType] = useState("");
  const [title, setTitle] = useState("");
  const [xAxis, setXAxis] = useState("");
  const [yAxis, setYAxis] = useState("");
  
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // Get user billing information
  const { data: billingData } = useQuery<{user: {planType: string}}>({
    queryKey: ['/api/billing/usage'],
  });
  const queryClient = useQueryClient();



  const handleEditVisualization = (visualization: Visualization) => {
    setSelectedVisualization(visualization);
    setTitle(visualization.title);
    setChartType(visualization.type);
    setEditDialogOpen(true);
  };

  const handleShareVisualization = async (visualization: Visualization) => {
    const shareUrl = `${window.location.origin}/visualizations/${visualization.id}`;
    
    try {
      await navigator.clipboard.writeText(shareUrl);
      toast({
        title: "Link Copied",
        description: "Visualization share link copied to clipboard.",
      });
    } catch (error) {
      toast({
        title: "Share Failed",
        description: "Failed to copy share link. Please try again.",
        variant: "destructive",
      });
    }
  };

  const generateVisualizationPNG = async (visualization: Visualization) => {
    try {
      const timestamp = new Date().toISOString().split('T')[0];
      const safeTitle = visualization.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
      
      // Create a temporary container for the chart
      const tempContainer = document.createElement('div');
      tempContainer.style.width = '800px';
      tempContainer.style.height = '600px';
      tempContainer.style.position = 'absolute';
      tempContainer.style.left = '-9999px';
      tempContainer.id = `temp-chart-${Date.now()}`;
      document.body.appendChild(tempContainer);

      // Create the plot
      const plotData = Array.isArray(visualization.visualization.data) 
        ? visualization.visualization.data 
        : [visualization.visualization.data];
      
      const plotLayout = {
        ...visualization.visualization.layout,
        width: 800,
        height: 500,
        title: {
          text: visualization.title,
          font: { size: 20 }
        },
        margin: { t: 80, r: 50, b: 80, l: 80 }
      };

      // Render plot using Plotly
      await new Promise((resolve, reject) => {
        import('plotly.js-dist').then((Plotly) => {
          Plotly.newPlot(tempContainer, plotData, plotLayout, {
            displayModeBar: false,
            staticPlot: true
          }).then(resolve).catch(reject);
        });
      });

      // Wait for rendering
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Capture the chart as canvas
      const canvas = await html2canvas(tempContainer, {
        width: 800,
        height: 600,
        scale: 2,
        backgroundColor: '#ffffff'
      });

      // Download PNG file
      const link = document.createElement('a');
      link.download = `${safeTitle}-${timestamp}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();

      // Cleanup
      document.body.removeChild(tempContainer);

      toast({
        title: "PNG Export Complete",
        description: `${visualization.title} exported as PNG image.`,
      });

    } catch (error) {
      console.error('PNG generation error:', error);
      toast({
        title: "PNG Export Failed",
        description: "Failed to generate PNG. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleTextDownload = async (visualization: Visualization) => {
    const timestamp = new Date().toISOString().split('T')[0];
    const safeTitle = visualization.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    
    let content = `DataDialogue AI - Visualization Export\n`;
    content += `Export Date: ${new Date().toLocaleString()}\n`;
    content += `Visualization Title: ${visualization.title}\n`;
    content += `Chart Type: ${visualization.type}\n`;
    content += `Created: ${new Date(visualization.createdAt).toLocaleString()}\n`;
    content += `Query: ${visualization.query}\n`;
    content += `\n${'='.repeat(50)}\n\n`;
    
    if (visualization.visualization?.data) {
      content += `DATA STRUCTURE:\n`;
      if (Array.isArray(visualization.visualization.data)) {
        visualization.visualization.data.forEach((series, i) => {
          content += `Series ${i + 1}: ${series.name || 'Unnamed'}\n`;
          if (series.x && series.y) {
            content += `  Data Points: ${Math.min(series.x.length, series.y.length)}\n`;
          }
        });
      }
    }
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${safeTitle}-${timestamp}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadVisualization = async (visualization: Visualization) => {
    // Check if user is on free tier
    if (billingData?.user?.planType === 'free') {
      toast({
        title: "Upgrade Feature",
        description: "Visualization export is available for paid plans only. Upgrade to access this feature.",
        variant: "destructive",
      });
      return;
    }

    if (visualization.visualization?.data) {
      await generateVisualizationPNG(visualization);
    } else {
      toast({
        title: "No Chart Data",
        description: "This visualization has no chart data to export as PNG.",
        variant: "destructive",
      });
    }
  };

  const deleteVisualizationMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/visualizations/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Visualization Deleted",
        description: "Visualization has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/visualizations"] });
    },
    onError: () => {
      toast({
        title: "Delete Failed",
        description: "Failed to delete visualization. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDeleteVisualization = (visualization: Visualization) => {
    if (confirm(`Are you sure you want to delete "${visualization.title}"?`)) {
      deleteVisualizationMutation.mutate(visualization.id);
    }
  };

  const editVisualizationMutation = useMutation({
    mutationFn: async (data: { id: string; title: string; type: string }) => {
      return await apiRequest("PATCH", `/api/visualizations/${data.id}`, data);
    },
    onSuccess: () => {
      toast({
        title: "Visualization Updated",
        description: "Visualization has been updated successfully.",
      });
      setEditDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/visualizations"] });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update visualization. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmitEdit = () => {
    if (!selectedVisualization || !title || !chartType) return;
    
    editVisualizationMutation.mutate({
      id: selectedVisualization.id,
      title,
      type: chartType,
    });
  };



  const getChartIcon = (type: string) => {
    switch (type) {
      case 'line': return LineChart;
      case 'bar': return BarChart3;
      case 'pie': return PieChart;
      default: return TrendingUp;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'line': return 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300';
      case 'bar': return 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300';
      case 'pie': return 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300';
      default: return 'bg-gray-100 text-gray-700 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Visualizations</h1>
          <p className="text-slate-600 dark:text-slate-400">Browse and manage your data visualizations</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 dark:text-slate-400">Total Charts</p>
                <p className="text-2xl font-bold text-slate-900 dark:text-slate-100">{visualizations.length}</p>
              </div>
              <BarChart3 className="w-8 h-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 dark:text-slate-400">Line Charts</p>
                <p className="text-2xl font-bold text-slate-900 dark:text-slate-100">
                  {visualizations.filter(v => v.type === 'line').length}
                </p>
              </div>
              <LineChart className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 dark:text-slate-400">Bar Charts</p>
                <p className="text-2xl font-bold text-slate-900 dark:text-slate-100">
                  {visualizations.filter(v => v.type === 'bar').length}
                </p>
              </div>
              <BarChart3 className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 dark:text-slate-400">Pie Charts</p>
                <p className="text-2xl font-bold text-slate-900 dark:text-slate-100">
                  {visualizations.filter(v => v.type === 'pie').length}
                </p>
              </div>
              <PieChart className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Visualizations Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4">
                <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded mb-2"></div>
                <div className="h-32 bg-slate-200 dark:bg-slate-700 rounded mb-2"></div>
                <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded w-2/3"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : visualizations.length === 0 ? (
        <Card className="p-12 text-center">
          <BarChart3 className="w-16 h-16 text-slate-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100 mb-2">
            No visualizations yet
          </h3>
          <p className="text-slate-600 dark:text-slate-400 mb-6">
            Start chatting with your data to generate visualizations automatically
          </p>
          <Button onClick={handleCreateVisualization}>
            <Plus className="w-4 h-4 mr-2" />
            Get Started
          </Button>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...visualizations].reverse().map((viz) => {
            const ChartIcon = getChartIcon(viz.type);
            return (
              <Card key={viz.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <ChartIcon className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{viz.title}</CardTitle>
                        <CardDescription className="text-sm">From conversation</CardDescription>
                      </div>
                    </div>
                    <Badge className={getTypeColor(viz.type)}>
                      {viz.type}
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent className="pt-0">
                  {/* Chart preview or placeholder */}
                  <div className="w-full h-32 bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-700 dark:to-slate-800 rounded-lg mb-4 flex items-center justify-center">
                    {viz.visualization?.data ? (
                      <div className="w-full h-full overflow-hidden rounded-lg">
                        <Plot
                          data={Array.isArray(viz.visualization.data) ? viz.visualization.data : [viz.visualization.data]}
                          layout={{
                            ...viz.visualization.layout,
                            width: 300,
                            height: 120,
                            margin: { t: 10, r: 10, b: 20, l: 30 },
                            showlegend: false
                          }}
                          config={{ displayModeBar: false, staticPlot: true }}
                        />
                      </div>
                    ) : (
                      <ChartIcon className="w-12 h-12 text-slate-400" />
                    )}
                  </div>
                  
                  <div className="flex items-center justify-between text-sm text-slate-600 dark:text-slate-400 mb-4">
                    <span>Created {new Date(viz.createdAt).toLocaleDateString()}</span>
                  </div>

                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => {
                        setSelectedVisualization(viz);
                        setViewDialogOpen(true);
                      }}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      View
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => handleDownloadVisualization(viz)}
                      disabled={billingData?.user?.planType === 'free'}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export PNG
                      {billingData?.user?.planType === 'free' && (
                        <span className="ml-1 text-xs text-orange-600 dark:text-orange-400">Upgrade</span>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Visualization</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="editTitle">Title</Label>
              <Input
                id="editTitle"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter visualization title"
              />
            </div>
            
            <div>
              <Label htmlFor="editChartType">Chart Type</Label>
              <Select value={chartType} onValueChange={setChartType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select chart type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="line">Line Chart</SelectItem>
                  <SelectItem value="bar">Bar Chart</SelectItem>
                  <SelectItem value="pie">Pie Chart</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setEditDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                className="flex-1"
                onClick={handleSubmitEdit}
                disabled={editVisualizationMutation.isPending || !title || !chartType}
              >
                {editVisualizationMutation.isPending ? "Updating..." : "Update"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle>{selectedVisualization?.title || 'Visualization'}</DialogTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setViewDialogOpen(false)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </DialogHeader>
          <div className="mt-4">
            {selectedVisualization?.visualization?.data ? (
              <div className="w-full h-96 bg-white dark:bg-slate-800 rounded-lg border">
                <Plot
                  data={Array.isArray(selectedVisualization.visualization.data) 
                    ? selectedVisualization.visualization.data 
                    : [selectedVisualization.visualization.data]
                  }
                  layout={{
                    ...selectedVisualization.visualization.layout,
                    autosize: true,
                    margin: { t: 50, r: 50, b: 50, l: 50 }
                  }}
                  config={{ 
                    displayModeBar: false,
                    responsive: true
                  }}
                  useResizeHandler={true}
                  style={{width: '100%', height: '400px'}}
                />
              </div>
            ) : (
              <div className="w-full h-96 bg-slate-100 dark:bg-slate-700 rounded-lg border flex items-center justify-center">
                <div className="text-center">
                  <BarChart3 className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-600 dark:text-slate-400">No visualization data available</p>
                </div>
              </div>
            )}
            
            {/* Visualization Details */}
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold text-slate-900 dark:text-slate-100 mb-2">Details</h4>
                <dl className="space-y-2">
                  <div>
                    <dt className="text-sm font-medium text-slate-600 dark:text-slate-400">Type</dt>
                    <dd className="text-sm text-slate-900 dark:text-slate-100">{selectedVisualization?.type}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-slate-600 dark:text-slate-400">Created</dt>
                    <dd className="text-sm text-slate-900 dark:text-slate-100">
                      {selectedVisualization?.createdAt ? new Date(selectedVisualization.createdAt).toLocaleString() : 'Unknown'}
                    </dd>
                  </div>
                </dl>
              </div>
              <div>
                <h4 className="font-semibold text-slate-900 dark:text-slate-100 mb-2">Query</h4>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {selectedVisualization?.query || 'No query information available'}
                </p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}