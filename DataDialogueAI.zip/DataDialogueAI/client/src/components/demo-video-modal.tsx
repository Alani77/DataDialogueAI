import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, X, Upload, MessageSquare, BarChart3, Clock } from "lucide-react";

interface DemoVideoModalProps {
  children: React.ReactNode;
}

export function DemoVideoModal({ children }: DemoVideoModalProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  const demoSteps = [
    {
      title: "Welcome to DataDialogue AI",
      description: "Your intelligent analytics platform that transforms data into insights",
      icon: Play,
      content: "DataDialogue AI makes data analysis accessible to everyone. No coding required - just upload your data and start asking questions in natural language.",
      highlight: "Transform raw data into actionable insights with AI"
    },
    {
      title: "Upload Your Data",
      description: "Support for multiple file formats with automatic detection",
      icon: Upload,
      content: "Simply drag and drop your CSV, Excel, JSON, XML, or TSV files. Our platform automatically detects the format and processes your data with intelligent column type detection.",
      highlight: "Supports CSV, Excel, JSON, XML, TSV formats"
    },
    {
      title: "Chat with Your Data",
      description: "Ask questions in natural language and get AI-powered answers",
      icon: MessageSquare,
      content: "Type questions like 'What are the sales trends?' or 'Which product performs best?' Our GPT-4 powered AI analyzes your data and provides detailed insights with explanations.",
      highlight: "Powered by OpenAI GPT-4 for intelligent analysis"
    },
    {
      title: "Interactive Visualizations",
      description: "Automatically generate charts and graphs",
      icon: BarChart3,
      content: "Get beautiful, interactive visualizations automatically generated based on your data. Bar charts, line graphs, pie charts, and more - all created intelligently by AI.",
      highlight: "Smart visualization recommendations"
    },
    {
      title: "Real-time Collaboration",
      description: "Share insights and reports with your team",
      icon: Clock,
      content: "Save your analysis, share reports with team members, and track your data exploration history. Everything syncs in real-time for seamless collaboration.",
      highlight: "Team collaboration features included"
    }
  ];

  const nextStep = () => {
    if (currentStep < demoSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const resetDemo = () => {
    setCurrentStep(0);
  };

  const currentStepData = demoSteps[currentStep];
  const StepIcon = currentStepData.icon;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-4xl w-full">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Play className="text-white w-5 h-5" />
            </div>
            Product Demo - DataDialogue AI
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Progress indicator */}
          <div className="flex items-center justify-between">
            <div className="flex space-x-2">
              {demoSteps.map((_, index) => (
                <div
                  key={index}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentStep
                      ? "bg-primary"
                      : index < currentStep
                      ? "bg-primary/60"
                      : "bg-gray-200 dark:bg-gray-700"
                  }`}
                />
              ))}
            </div>
            <Badge variant="outline">
              Step {currentStep + 1} of {demoSteps.length}
            </Badge>
          </div>

          {/* Demo content */}
          <div className="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-900 rounded-xl p-8 min-h-[400px] flex flex-col justify-center">
            <div className="text-center space-y-6">
              <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto">
                <StepIcon className="w-10 h-10 text-primary" />
              </div>
              
              <div className="space-y-3">
                <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
                  {currentStepData.title}
                </h3>
                <p className="text-lg text-slate-600 dark:text-slate-400">
                  {currentStepData.description}
                </p>
              </div>

              <div className="max-w-2xl mx-auto">
                <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                  {currentStepData.content}
                </p>
              </div>

              <Badge className="bg-primary/10 text-primary border-primary/20 px-4 py-2">
                {currentStepData.highlight}
              </Badge>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              onClick={prevStep}
              disabled={currentStep === 0}
            >
              Previous
            </Button>

            <div className="flex gap-3">
              {currentStep === demoSteps.length - 1 ? (
                <>
                  <Button variant="outline" onClick={resetDemo}>
                    Replay Demo
                  </Button>
                  <Button asChild>
                    <a href="/api/login">Get Started Free</a>
                  </Button>
                </>
              ) : (
                <Button onClick={nextStep}>
                  Next Step
                </Button>
              )}
            </div>
          </div>

          {/* Demo features list */}
          <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-slate-200 dark:border-slate-700">
            <h4 className="font-semibold text-slate-900 dark:text-slate-100 mb-3">
              What you'll get with DataDialogue AI:
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
              <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                Multi-format data upload support
              </div>
              <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                AI-powered natural language queries
              </div>
              <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                Automatic visualization generation
              </div>
              <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                Real-time team collaboration
              </div>
              <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                Secure cloud-based processing
              </div>
              <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                Export and sharing capabilities
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}