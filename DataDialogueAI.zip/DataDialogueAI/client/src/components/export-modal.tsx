import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Download } from "lucide-react";

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  datasetId: string | null;
}

export default function ExportModal({ isOpen, onClose, datasetId }: ExportModalProps) {
  const [exportFormat, setExportFormat] = useState("pdf");
  const [includeVisualizations, setIncludeVisualizations] = useState(true);
  const [includeInsights, setIncludeInsights] = useState(true);
  const [includeRawData, setIncludeRawData] = useState(false);
  const [includeChat, setIncludeChat] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  
  const { toast } = useToast();

  const handleExport = async () => {
    if (!datasetId) {
      toast({
        title: "Export error",
        description: "No dataset selected for export",
        variant: "destructive",
      });
      return;
    }

    setIsExporting(true);
    
    try {
      // Simulate export process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "Export successful",
        description: `Your ${exportFormat.toUpperCase()} report has been generated`,
      });
      
      // In a real implementation, you'd trigger the actual download here
      const filename = `data-analysis-report.${exportFormat}`;
      
      onClose();
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Failed to generate export file",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Export Data & Insights</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="format" className="text-sm font-medium text-slate-700 mb-2 block">
              Export Format
            </Label>
            <Select value={exportFormat} onValueChange={setExportFormat}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pdf">PDF Report</SelectItem>
                <SelectItem value="xlsx">Excel Spreadsheet</SelectItem>
                <SelectItem value="csv">CSV Data</SelectItem>
                <SelectItem value="pptx">PowerPoint Slides</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm font-medium text-slate-700 mb-2 block">
              Include
            </Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="visualizations"
                  checked={includeVisualizations}
                  onCheckedChange={(checked) => setIncludeVisualizations(checked === true)}
                />
                <Label htmlFor="visualizations" className="text-sm text-slate-700">
                  Data visualizations
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="insights"
                  checked={includeInsights}
                  onCheckedChange={(checked) => setIncludeInsights(checked === true)}
                />
                <Label htmlFor="insights" className="text-sm text-slate-700">
                  AI insights
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="raw-data"
                  checked={includeRawData}
                  onCheckedChange={(checked) => setIncludeRawData(checked === true)}
                />
                <Label htmlFor="raw-data" className="text-sm text-slate-700">
                  Raw data
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="chat"
                  checked={includeChat}
                  onCheckedChange={(checked) => setIncludeChat(checked === true)}
                />
                <Label htmlFor="chat" className="text-sm text-slate-700">
                  Chat conversation
                </Label>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end space-x-3 pt-4">
          <Button variant="outline" onClick={onClose} disabled={isExporting}>
            Cancel
          </Button>
          <Button 
            onClick={handleExport} 
            disabled={isExporting}
            className="bg-primary text-white hover:bg-primary/90"
          >
            {isExporting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Generating...
              </>
            ) : (
              <>
                <Download className="w-4 h-4 mr-2" />
                Download
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
