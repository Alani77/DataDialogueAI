import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { Link } from "wouter";
import { 
  Home, 
  Upload, 
  BarChart3, 
  ChartLine,
  Crown
} from "lucide-react";

interface SidebarProps {
  selectedDatasetId: string | null;
  onDatasetSelect: (id: string | null) => void;
  activeView: string;
  onViewChange: (view: string) => void;
}

interface Dataset {
  id: string;
  filename: string;
  fileType: string;
  rowCount: number;
  uploadedAt: string;
}

export default function Sidebar({ selectedDatasetId, onDatasetSelect, activeView, onViewChange }: SidebarProps) {
  const { data: datasets = [] } = useQuery<Dataset[]>({
    queryKey: ['/api/datasets'],
  });

  const { data: userStats } = useQuery<{user: {planType: string}}>({
    queryKey: ['/api/billing/usage'],
  });

  const navItems = [
    { icon: Home, label: "Dashboard", value: "dashboard" },
    { icon: Upload, label: "Upload Data", value: "upload" },
    { icon: BarChart3, label: "Visualizations", value: "visualizations" },
  ];

  return (
    <div className="w-64 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 flex flex-col">
      {/* Logo & Brand */}
      <div className="p-6 border-b border-slate-200 dark:border-slate-700">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <ChartLine className="text-white text-sm" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">DataDialogue AI</h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">Intelligent Analytics</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item, index) => (
          <button
            key={index}
            onClick={() => onViewChange(item.value)}
            className={cn(
              "flex items-center space-x-3 px-3 py-2 rounded-lg w-full text-left transition-colors",
              activeView === item.value 
                ? "bg-primary/10 text-primary font-medium" 
                : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100"
            )}
          >
            <item.icon className="w-4 h-4" />
            <span>{item.label}</span>
          </button>
        ))}

        {/* Enterprise Features Link */}
        {userStats?.user?.planType === 'enterprise' && (
          <Link href="/enterprise">
            <button className="flex items-center space-x-3 px-3 py-2 rounded-lg w-full text-left transition-colors text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100 border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/20">
              <Crown className="w-4 h-4 text-amber-600" />
              <span className="text-amber-700 dark:text-amber-300">Enterprise Features</span>
            </button>
          </Link>
        )}

        {/* Datasets Section */}
        {datasets.length > 0 && (
          <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-700">
            <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2 px-3">Recent Datasets</p>
            <div className="space-y-1">
              {datasets.slice(0, 5).map((dataset) => (
                <button
                  key={dataset.id}
                  onClick={() => onDatasetSelect(dataset.id)}
                  className={cn(
                    "flex flex-col items-start px-3 py-2 rounded-lg w-full text-left transition-colors",
                    selectedDatasetId === dataset.id
                      ? "bg-primary/10 text-primary"
                      : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100"
                  )}
                >
                  <span className="text-sm font-medium truncate w-full">
                    {dataset.filename}
                  </span>
                  <span className="text-xs text-slate-500 dark:text-slate-400">
                    {dataset.rowCount} rows • {dataset.fileType.toUpperCase()}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>


    </div>
  );
}
