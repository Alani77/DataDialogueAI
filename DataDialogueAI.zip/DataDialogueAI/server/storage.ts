import { type User, type InsertUser, type UpsertUser, type Dataset, type InsertDataset, type Conversation, type InsertConversation, type Insight, type InsertInsight, users, datasets, conversations, insights } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Dataset operations
  getDataset(id: string): Promise<Dataset | undefined>;
  getDatasets(userId: string): Promise<Dataset[]>;
  getDatasetsByUserId(userId: string): Promise<Dataset[]>;
  createDataset(dataset: InsertDataset): Promise<Dataset>;
  deleteDataset(id: string): Promise<boolean>;

  // Conversation operations
  getConversation(id: string): Promise<Conversation | undefined>;
  getConversations(userId: string): Promise<Conversation[]>;
  getConversationsByDatasetId(datasetId: string): Promise<Conversation[]>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  updateConversation(id: string, messages: any[]): Promise<Conversation | undefined>;

  // Insight operations
  getInsight(id: string): Promise<Insight | undefined>;
  getInsights(userId: string): Promise<Insight[]>;
  getInsightsByDatasetId(datasetId: string): Promise<Insight[]>;
  createInsight(insight: InsertInsight): Promise<Insight>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getDataset(id: string): Promise<Dataset | undefined> {
    const [dataset] = await db.select().from(datasets).where(eq(datasets.id, id));
    return dataset || undefined;
  }

  async getDatasets(userId: string): Promise<Dataset[]> {
    return await db.select().from(datasets).where(eq(datasets.userId, userId));
  }

  async getDatasetsByUserId(userId: string): Promise<Dataset[]> {
    return await db.select().from(datasets).where(eq(datasets.userId, userId));
  }

  async createDataset(insertDataset: InsertDataset): Promise<Dataset> {
    const [dataset] = await db
      .insert(datasets)
      .values(insertDataset)
      .returning();
    return dataset;
  }

  async deleteDataset(id: string): Promise<boolean> {
    const result = await db.delete(datasets).where(eq(datasets.id, id));
    return (result.rowCount || 0) > 0;
  }

  async getConversation(id: string): Promise<Conversation | undefined> {
    const [conversation] = await db.select().from(conversations).where(eq(conversations.id, id));
    return conversation || undefined;
  }

  async getConversations(userId: string): Promise<Conversation[]> {
    return await db.select().from(conversations).where(eq(conversations.userId, userId));
  }

  async getConversationsByDatasetId(datasetId: string): Promise<Conversation[]> {
    return await db.select().from(conversations).where(eq(conversations.datasetId, datasetId));
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const [conversation] = await db
      .insert(conversations)
      .values({
        ...insertConversation,
        messages: Array.isArray(insertConversation.messages) ? insertConversation.messages : []
      })
      .returning();
    return conversation;
  }

  async updateConversation(id: string, messages: any[]): Promise<Conversation | undefined> {
    const [conversation] = await db
      .update(conversations)
      .set({ messages })
      .where(eq(conversations.id, id))
      .returning();
    return conversation || undefined;
  }

  async getInsight(id: string): Promise<Insight | undefined> {
    const [insight] = await db.select().from(insights).where(eq(insights.id, id));
    return insight || undefined;
  }

  async getInsights(userId: string): Promise<Insight[]> {
    return await db.select().from(insights).where(eq(insights.userId, userId));
  }

  async getInsightsByDatasetId(datasetId: string): Promise<Insight[]> {
    return await db.select().from(insights).where(eq(insights.datasetId, datasetId));
  }

  async createInsight(insertInsight: InsertInsight): Promise<Insight> {
    const [insight] = await db
      .insert(insights)
      .values(insertInsight)
      .returning();
    return insight;
  }
}

export const storage = new DatabaseStorage();
