import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { DataColumn } from '@shared/schema';

export interface ProcessedData {
  data: any[];
  columns: DataColumn[];
  filename: string;
  fileType: string;
  rowCount: number;
}

export function processCSV(fileContent: string, filename: string): ProcessedData {
  const result = Papa.parse(fileContent, {
    header: true,
    skipEmptyLines: true,
    transformHeader: (header) => header.trim(),
    transform: (value) => {
      // Try to parse numbers
      if (!isNaN(Number(value)) && value.trim() !== '') {
        return Number(value);
      }
      // Try to parse dates
      if (Date.parse(value)) {
        return new Date(value);
      }
      return value;
    }
  });

  if (result.errors.length > 0) {
    throw new Error(`CSV parsing error: ${result.errors[0].message}`);
  }

  const data = result.data as any[];
  const columns = inferColumns(data);

  return {
    data,
    columns,
    filename,
    fileType: 'csv',
    rowCount: data.length
  };
}

export function processTSV(fileContent: string, filename: string): ProcessedData {
  const result = Papa.parse(fileContent, {
    header: true,
    delimiter: '\t',
    skipEmptyLines: true,
    transformHeader: (header) => header.trim(),
    transform: (value) => {
      if (!isNaN(Number(value)) && value.trim() !== '') {
        return Number(value);
      }
      if (Date.parse(value)) {
        return new Date(value);
      }
      return value;
    }
  });

  if (result.errors.length > 0) {
    throw new Error(`TSV parsing error: ${result.errors[0].message}`);
  }

  const data = result.data as any[];
  const columns = inferColumns(data);

  return {
    data,
    columns,
    filename,
    fileType: 'tsv',
    rowCount: data.length
  };
}

export function processExcel(buffer: Buffer, filename: string): ProcessedData {
  try {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    
    const data = XLSX.utils.sheet_to_json(worksheet, {
      raw: false,
      dateNF: 'yyyy-mm-dd'
    }) as any[];

    const columns = inferColumns(data);

    return {
      data,
      columns,
      filename,
      fileType: filename.endsWith('.xlsx') ? 'xlsx' : 'xls',
      rowCount: data.length
    };
  } catch (error) {
    throw new Error(`Excel processing error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export function processJSON(fileContent: string, filename: string): ProcessedData {
  try {
    let data = JSON.parse(fileContent);
    
    // Handle different JSON structures
    if (!Array.isArray(data)) {
      if (typeof data === 'object' && data !== null) {
        // If it's an object, try to find an array property
        const arrayKey = Object.keys(data).find(key => Array.isArray(data[key]));
        if (arrayKey) {
          data = data[arrayKey];
        } else {
          // Convert single object to array
          data = [data];
        }
      } else {
        throw new Error('JSON must contain an array or object with array property');
      }
    }

    const columns = inferColumns(data);

    return {
      data,
      columns,
      filename,
      fileType: 'json',
      rowCount: data.length
    };
  } catch (error) {
    throw new Error(`JSON processing error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export function processXML(fileContent: string, filename: string): ProcessedData {
  // Basic XML to JSON conversion
  try {
    // This is a simplified XML parser - in production, you'd use a proper XML library
    const xmlParser = new DOMParser();
    const xmlDoc = xmlParser.parseFromString(fileContent, 'text/xml');
    
    if (xmlDoc.getElementsByTagName('parsererror').length > 0) {
      throw new Error('Invalid XML format');
    }

    // Convert XML to JSON-like structure
    const data = xmlToJson(xmlDoc.documentElement);
    let arrayData: any[] = [];

    // Try to find array-like structures in the XML
    if (Array.isArray(data)) {
      arrayData = data;
    } else if (typeof data === 'object' && data !== null) {
      // Look for repeated elements that could represent rows
      const keys = Object.keys(data);
      for (const key of keys) {
        if (Array.isArray(data[key])) {
          arrayData = data[key];
          break;
        }
      }
      if (arrayData.length === 0) {
        arrayData = [data];
      }
    }

    const columns = inferColumns(arrayData);

    return {
      data: arrayData,
      columns,
      filename,
      fileType: 'xml',
      rowCount: arrayData.length
    };
  } catch (error) {
    throw new Error(`XML processing error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

function xmlToJson(xml: Element): any {
  const obj: any = {};
  
  if (xml.hasAttributes()) {
    for (let i = 0; i < xml.attributes.length; i++) {
      const attribute = xml.attributes[i];
      obj[`@${attribute.nodeName}`] = attribute.nodeValue;
    }
  }

  if (xml.hasChildNodes()) {
    for (let i = 0; i < xml.childNodes.length; i++) {
      const item = xml.childNodes[i];
      const nodeName = item.nodeName;
      
      if (item.nodeType === 1) { // Element node
        if (typeof obj[nodeName] === 'undefined') {
          obj[nodeName] = xmlToJson(item as Element);
        } else {
          if (!Array.isArray(obj[nodeName])) {
            obj[nodeName] = [obj[nodeName]];
          }
          obj[nodeName].push(xmlToJson(item as Element));
        }
      } else if (item.nodeType === 3 && item.nodeValue?.trim()) { // Text node
        return item.nodeValue.trim();
      }
    }
  }
  
  return obj;
}

function inferColumns(data: any[]): DataColumn[] {
  if (data.length === 0) return [];

  const columns: DataColumn[] = [];
  const firstRow = data[0];
  
  for (const [key, value] of Object.entries(firstRow)) {
    const column: DataColumn = {
      name: key,
      type: inferColumnType(data, key),
      nullable: data.some(row => row[key] === null || row[key] === undefined || row[key] === '')
    };
    columns.push(column);
  }

  return columns;
}

function inferColumnType(data: any[], columnName: string): 'string' | 'number' | 'date' | 'boolean' {
  const values = data.map(row => row[columnName]).filter(val => val !== null && val !== undefined && val !== '');
  
  if (values.length === 0) return 'string';

  // Check for booleans
  if (values.every(val => typeof val === 'boolean' || val === 'true' || val === 'false' || val === 0 || val === 1)) {
    return 'boolean';
  }

  // Check for numbers
  if (values.every(val => !isNaN(Number(val)))) {
    return 'number';
  }

  // Check for dates
  if (values.every(val => !isNaN(Date.parse(val)))) {
    return 'date';
  }

  return 'string';
}
