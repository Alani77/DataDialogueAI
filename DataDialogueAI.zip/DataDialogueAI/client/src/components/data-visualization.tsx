import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import Plot from "react-plotly.js";
import { TrendingUp, Users, BarChart3, Calendar } from "lucide-react";
import { useState, useEffect } from "react";

interface DataVisualizationProps {
  datasetId: string;
}

interface Dataset {
  id: string;
  filename: string;
  fileType: string;
  data: any[];
  columns: Array<{
    name: string;
    type: 'string' | 'number' | 'date' | 'boolean';
    nullable: boolean;
  }>;
  rowCount: number;
  uploadedAt: string;
}

interface QuickStats {
  totalRows: number;
  numericColumns: number;
  textColumns: number;
  dateColumns: number;
}

export default function DataVisualization({ datasetId }: DataVisualizationProps) {
  const [quickStats, setQuickStats] = useState<QuickStats | null>(null);

  const { data: dataset, isLoading } = useQuery<Dataset>({
    queryKey: ['/api/datasets', datasetId],
  });

  useEffect(() => {
    if (dataset) {
      const stats: QuickStats = {
        totalRows: dataset.rowCount,
        numericColumns: dataset.columns.filter(col => col.type === 'number').length,
        textColumns: dataset.columns.filter(col => col.type === 'string').length,
        dateColumns: dataset.columns.filter(col => col.type === 'date').length,
      };
      setQuickStats(stats);
    }
  }, [dataset]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-32" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-64 w-full" />
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-32" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-64 w-full" />
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!dataset) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-600">Dataset not found</p>
      </div>
    );
  }

  // Generate sample visualizations based on data
  const generateSampleChart = (type: 'line' | 'bar') => {
    const numericColumns = dataset.columns.filter(col => col.type === 'number');
    if (numericColumns.length === 0) return null;

    const firstNumericCol = numericColumns[0];
    const values = dataset.data.map(row => row[firstNumericCol.name]).filter(val => val != null);
    
    if (type === 'line') {
      return {
        data: [{
          x: values.map((_, i) => i + 1),
          y: values.slice(0, 20),
          type: 'scatter',
          mode: 'lines+markers',
          marker: { color: '#3B82F6', size: 6 },
          line: { color: '#3B82F6', width: 3 },
        }],
        layout: {
          margin: { t: 20, r: 20, b: 40, l: 60 },
          xaxis: { showgrid: false, showline: false, title: { text: 'Index' } },
          yaxis: { showgrid: true, gridcolor: '#f1f5f9', showline: false, title: { text: firstNumericCol.name } },
          plot_bgcolor: 'transparent',
          paper_bgcolor: 'transparent',
          font: { family: 'Inter, sans-serif', size: 12, color: '#64748b' }
        }
      };
    } else {
      return {
        data: [{
          x: values.slice(0, 10).map((_, i) => `Row ${i + 1}`),
          y: values.slice(0, 10),
          type: 'bar',
          marker: { color: '#6366F1', opacity: 0.8 }
        }],
        layout: {
          margin: { t: 20, r: 20, b: 40, l: 60 },
          xaxis: { showgrid: false, showline: false },
          yaxis: { showgrid: true, gridcolor: '#f1f5f9', showline: false, title: { text: firstNumericCol.name } },
          plot_bgcolor: 'transparent',
          paper_bgcolor: 'transparent',
          font: { family: 'Inter, sans-serif', size: 12, color: '#64748b' }
        }
      };
    }
  };

  const lineChart = generateSampleChart('line');
  const barChart = generateSampleChart('bar');

  return (
    <div className="space-y-8">
      {/* Dataset Info */}
      <div>
        <h3 className="text-xl font-semibold text-slate-900 mb-2">{dataset.filename}</h3>
        <div className="flex items-center space-x-4">
          <Badge variant="outline">{dataset.fileType.toUpperCase()}</Badge>
          <span className="text-sm text-slate-600">{dataset.rowCount} rows</span>
          <span className="text-sm text-slate-600">{dataset.columns.length} columns</span>
        </div>
      </div>

      {/* Data Preview & Quick Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Data Preview */}
        <Card>
          <CardHeader>
            <CardTitle>Data Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-auto max-h-64">
              <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    {dataset.columns.slice(0, 4).map((column) => (
                      <th key={column.name} className="px-3 py-2 text-left font-medium text-slate-700">
                        {column.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {dataset.data.slice(0, 10).map((row, index) => (
                    <tr key={index}>
                      {dataset.columns.slice(0, 4).map((column) => (
                        <td key={column.name} className="px-3 py-2 text-slate-600">
                          {row[column.name]?.toString() || '—'}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Insights</CardTitle>
          </CardHeader>
          <CardContent>
            {quickStats && (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-success/5 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-success rounded-lg flex items-center justify-center">
                      <BarChart3 className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-900">Total Rows</p>
                      <p className="text-xs text-slate-600">Dataset size</p>
                    </div>
                  </div>
                  <span className="text-lg font-bold text-success">{quickStats.totalRows.toLocaleString()}</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-primary/5 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                      <TrendingUp className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-900">Numeric Columns</p>
                      <p className="text-xs text-slate-600">Quantitative data</p>
                    </div>
                  </div>
                  <span className="text-lg font-bold text-primary">{quickStats.numericColumns}</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-secondary/5 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-secondary rounded-lg flex items-center justify-center">
                      <Users className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-900">Text Columns</p>
                      <p className="text-xs text-slate-600">Categorical data</p>
                    </div>
                  </div>
                  <span className="text-lg font-bold text-secondary">{quickStats.textColumns}</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Sample Visualizations */}
      {(lineChart || barChart) && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {lineChart && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Data Trend</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">7D</Button>
                    <Button size="sm" className="bg-primary text-white">30D</Button>
                    <Button variant="outline" size="sm">90D</Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Plot
                  data={lineChart.data}
                  layout={lineChart.layout}
                  config={{ displayModeBar: false, responsive: true }}
                  style={{ width: '100%', height: '300px' }}
                />
              </CardContent>
            </Card>
          )}

          {barChart && (
            <Card>
              <CardHeader>
                <CardTitle>Data Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <Plot
                  data={barChart.data}
                  layout={barChart.layout}
                  config={{ displayModeBar: false, responsive: true }}
                  style={{ width: '100%', height: '300px' }}
                />
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* AI Insights Placeholder */}
      <Card className="bg-gradient-to-r from-primary/5 to-secondary/5 border-primary/10">
        <CardHeader>
          <CardTitle className="flex items-center">
            <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center mr-2">
              <span className="text-white text-xs">AI</span>
            </div>
            AI-Generated Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-slate-600 mb-4">
              Start a conversation in the chat panel to get AI-powered insights about your data.
            </p>
            <Button className="bg-primary text-white hover:bg-primary/90">
              Ask AI a Question
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
